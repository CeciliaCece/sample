package com.kucw.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson85ApplicationTests {

    @Test
    void contextLoads() {
    }

}
