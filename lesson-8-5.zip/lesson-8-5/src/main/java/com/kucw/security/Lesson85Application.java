package com.kucw.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson85Application {

    public static void main(String[] args) {
        SpringApplication.run(Lesson85Application.class, args);
    }

}
