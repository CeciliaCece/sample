import { createRouter, createWebHistory, RouteRecordRaw } from "vue-router";
import HomeView from "../views/HomeView.vue";
import LoginView from "../views/LoginView.vue";
import RegisterView from "../views/RegisterView.vue";
import ProductView from "../views/ProductView.vue";
import OrderView from "../views/OrderView.vue";

import NotFound from "../views/NotFound.vue";
import store from "../store";
import DashBoard from "../views/layouts/DashBoard.vue";

const routes: Array<RouteRecordRaw> = [
  { path: "/", component: HomeView },
  { path: "/login", component: LoginView },
  { path: "/register", component: RegisterView },
  { path: "/product/:id", component: ProductView },
  {
    path: "/order",
    component: OrderView,
    meta: { roles: ["ROLE_ADMIN", "ROLE_CUSTOMER"] },
  },
  {
    path: "/admin",
    component: DashBoard,
    meta: {
      roles: ["ROLE_ADMIN", "ROLE_MANAGER"],
    },
    children: [
      {
        path: "manageOrder",
        name: "manageOrder",
        component: () => import("../views/ManageOrderView.vue"),
      },
      {
        path: "manageProduct",
        name: "manageProduct",
        component: () => import("../views/ManageProductView.vue"),
      },
      {
        path: "addProduct",
        name: "addProduct",
        component: () => import("../views/UpdateProductView.vue"),
      },
      {
        path: "editProduct/:id",
        name: "editProduct",
        component: () => import("../views/UpdateProductView.vue"),
      },
    ],
  },
  { path: "/:pathMatch(.*)*", component: NotFound },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach(async (to, from, next) => {
  const roles = to.meta.roles as string[] | undefined;
  const token = store.getters.token;
  const userRole = store.getters.userRole;

  if (roles && token) {
    try {
      if (!roles.includes(userRole)) {
        next("/login");
      } else {
        next();
      }
    } catch (error) {
      next("/login");
    }
  } else {
    next();
  }
});

export default router;
