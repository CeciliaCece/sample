package com.example.sample.utils;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ResultSetUtil {

    public static String getStringSafe(ResultSet rs, String columnName) {
        try {
            return rs.getString(columnName);
        } catch (SQLException e) {
            return null;
        }
    }

    public static Integer getIntSafe(ResultSet rs, String columnName) {
        try {
            return rs.getInt(columnName);
        } catch (SQLException e) {
            return 0;
        }
    }

    public static BigDecimal getBigDecimalSafe(ResultSet rs, String columnName) {
        try {
            return rs.getBigDecimal(columnName);
        } catch (SQLException e) {
            return BigDecimal.ZERO;
        }
    }

    public static Array getArrayStringSafe(ResultSet rs, String columnName) {
        try {
            return rs.getArray(columnName);
        } catch (SQLException e) {
            return null;
        }
    }

    public static Array getArrayIntegerSafe(ResultSet rs, String columnName) {
        try {
            return rs.getArray(columnName);
        } catch (SQLException e) {
            try {
                // 获取数据库连接并创建一个空的 Array 对象
                Connection conn = rs.getStatement().getConnection();
                return conn.createArrayOf("INTEGER", new Integer[0]);
            } catch (SQLException ex) {
                // 如果无法创建空的 Array 对象，则返回 null
                return null;
            }
        }
    }
}