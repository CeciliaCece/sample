package com.example.sample.dao.mapper;

import com.example.sample.constant.DbConst;
import com.example.sample.dao.bean.PermissionPO;
import com.example.sample.utils.ResultSetUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PermissionMapper implements RowMapper<PermissionPO> {

    @Override
    public PermissionPO mapRow(ResultSet rs, int rowNum) throws SQLException {
        Array rolesArray = ResultSetUtil.getArrayStringSafe(rs, DbConst.TB_PERMISSIONROLES_PERMISSION_ROLES);
        List<String> rolesList = rolesArray != null ? Arrays.stream((String[]) rolesArray.getArray()).collect(Collectors.toList()) : null;

        Array rolesIdArray = ResultSetUtil.getArrayIntegerSafe(rs, DbConst.TB_PERMISSIONROLES_PERMISSION_ROLES_ID);
        List<Integer> rolesIdList = rolesIdArray != null ? Arrays.stream((Integer[]) rolesIdArray.getArray()).collect(Collectors.toList()) : null;

        return PermissionPO.builder()
                .permissionId(ResultSetUtil.getIntSafe(rs, DbConst.TB_PERMISSIONROLES_PERMISSION_ID))
                .permissionName(ResultSetUtil.getStringSafe(rs, DbConst.TB_PERMISSIONROLES_PERMISSION_NAME))
                .permissionCname(ResultSetUtil.getStringSafe(rs, DbConst.TB_PERMISSIONROLES_PERMISSION_CNAME))
                .permissionRoles(rolesList)
                .permissionRolesId(rolesIdList)
                .build();
    }
}