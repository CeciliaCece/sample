package com.example.sample.aop.aspect;

import com.example.sample.annotation.SimpleLog;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;
import java.util.Optional;

import static com.example.sample.constant.AopConst.POINTCUT_SIMPLE_LOG_LAYER;

@Aspect
@Setter
public class SimpleLogAspect {

    private static final Logger LOG = LogManager.getLogger(SimpleLogAspect.class.getName());

    @Before(value = POINTCUT_SIMPLE_LOG_LAYER)
    public void recordSimpleLog(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();

        Optional<SimpleLog> simpleLogAnnotationOpt = Optional.ofNullable(method.getAnnotation(SimpleLog.class));

        if (simpleLogAnnotationOpt.isPresent()) {
            LOG.info("It is Simple.");
        } else {
            LOG.info("It is not Simple.");
        }

    }
}