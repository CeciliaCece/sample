package com.example.sample.exception;

import com.example.sample.constant.ReturnCode;
import lombok.Getter;

@Getter
public class SampleException extends RuntimeException {

    static final long serialVersionUID = 944653487076681753L;


    private ReturnCode returnCode;

    public SampleException(ReturnCode returnCode) {
        super(new StringBuilder(returnCode.getCode())
                .append(":")
                .append(returnCode.getValue())
                .toString());
        this.returnCode = returnCode;
    }

    public SampleException(ReturnCode returnCode, Throwable cause) {
        super(cause);
        this.returnCode = returnCode;
    }
}