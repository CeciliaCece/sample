package com.example.sample.controller.bean.cart;

import lombok.Data;

@Data
public class UpdateCartRequestDTO {
    private String username;
    private int productId;
    private int amount;
}
