package com.example.sample.controller.bean.product;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProductResponseDTO {
        private List<ProductDetails> productDetails;

        @Data
        public static class ProductDetails{
                private int productId;
                private String productName;
                private String description;
                private BigDecimal price;
                private int stock;
        }

}



