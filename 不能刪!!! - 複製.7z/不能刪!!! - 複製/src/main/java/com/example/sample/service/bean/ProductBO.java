package com.example.sample.service.bean;

import com.example.sample.dao.bean.ProductPO;
import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductBO {
    private int productId;
    private String productName;
    private String description;
    private BigDecimal price;
    private int stock;
}
