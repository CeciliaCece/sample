package com.example.sample.controller.mapper;

import com.example.sample.controller.bean.cart.AddCartRequestDTO;
import com.example.sample.controller.bean.cart.DeleteCartRequestDTO;
import com.example.sample.controller.bean.cart.GetCartRequestDTO;
import com.example.sample.controller.bean.cart.UpdateCartRequestDTO;
import com.example.sample.service.bean.CartBO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CartControllerMapper {
    @Autowired
    ModelMapper modelMapper;

    public CartBO toAddCartRequestBO(AddCartRequestDTO addCartRequestDTO) {
        return modelMapper.map(addCartRequestDTO, CartBO.class);
    }

    public CartBO toDeleteCartRequestBO(DeleteCartRequestDTO deleteCartRequestDTO) {
        return modelMapper.map(deleteCartRequestDTO, CartBO.class);
    }

    public CartBO toUpdateCartRequestBO(UpdateCartRequestDTO updateCartRequestDTO) {
        return modelMapper.map(updateCartRequestDTO, CartBO.class);
    }

    public CartBO toGetCartRequestBO(GetCartRequestDTO getCartRequestDTO) {
        return modelMapper.map(getCartRequestDTO, CartBO.class);
    }
}
