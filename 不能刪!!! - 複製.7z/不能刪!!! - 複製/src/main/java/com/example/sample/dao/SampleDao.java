package com.example.sample.dao;

import com.example.sample.dao.bean.BankInfoPO;

public interface SampleDao {
    BankInfoPO getBankInfo(String bankCode, String branchCode);
}