package com.example.sample.constant;

public class ProcedureConst {

    public static final String PC_G_PRODUCT = "pc_g_product";
    public static final String PC_Q_PRODUCT = "pc_q_product";
    public static final String PC_C_PRODUCT = "pc_c_product";
    public static final String PC_U_PRODUCT = "pc_u_product";
    public static final String PC_D_PRODUCT = "pc_d_product";

    public static final String PC_G_USERINFO = "pc_g_userinfo";
    public static final String PC_C_USERINFO = "pc_c_userinfo";

    public static final String PC_G_PERMISSIONROLES = "pc_g_permissionroles";
    public static final String PC_Q_PERMISSIONROLES = "pc_q_permissionroles";
    public static final String PC_U_PERMISSIONROLES = "pc_u_permissionroles";

    public static final String PC_Q_ORDER = "pc_q_order";
    public static final String PC_C_ORDER = "pc_c_order";
    public static final String PC_G_ORDER = "pc_g_order";
    public static final String PC_U_ORDER = "pc_u_order";

    public static final String PC_Q_BUYLIST = "pc_q_buylist";

    public static final String PC_G_CART = "pc_g_cart";
    public static final String PC_C_CART = "pc_c_cart";
    public static final String PC_U_CART = "pc_u_cart";
    public static final String PC_D_CART = "pc_d_cart";




}