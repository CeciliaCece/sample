package com.example.sample.dao.bean;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class BuyListPO {
    private int productId;
    private String productName;
    private BigDecimal price;
    private int amount;

}