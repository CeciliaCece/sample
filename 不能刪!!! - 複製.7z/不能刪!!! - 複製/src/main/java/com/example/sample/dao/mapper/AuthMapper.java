package com.example.sample.dao.mapper;

import com.example.sample.constant.DbConst;
import com.example.sample.dao.bean.AuthPO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.example.sample.utils.ResultSetUtil.getStringSafe;

public class AuthMapper implements RowMapper<AuthPO> {
    @Override
    public AuthPO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return AuthPO.builder()
                .username(getStringSafe(rs, DbConst.TB_USERINFO_USERNAME))
                .userPassword(getStringSafe(rs, DbConst.TB_USERINFO_USER_PASSWORD))
                .lastName(getStringSafe(rs, DbConst.TB_USERINFO_LAST_NAME))
                .firstName(getStringSafe(rs, DbConst.TB_USERINFO_FIRST_NAME))
                .phone(getStringSafe(rs, DbConst.TB_USERINFO_PHONE))
                .userRole(getStringSafe(rs, DbConst.TB_USERINFO_USER_ROLE)).build();
    }

}