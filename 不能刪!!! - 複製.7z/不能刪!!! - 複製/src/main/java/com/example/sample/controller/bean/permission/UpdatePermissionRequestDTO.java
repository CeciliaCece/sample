package com.example.sample.controller.bean.permission;

import lombok.Data;

import java.util.List;

@Data
public class UpdatePermissionRequestDTO {
    private int permissionId;
    private List<Integer> permissionRoles;
}
