package com.example.sample.service.mapper;

import com.example.sample.controller.bean.product.GetProductResponseDTO;
import com.example.sample.controller.bean.product.QueryProductResponseDTO;
import com.example.sample.dao.bean.ProductPO;
import com.example.sample.service.bean.ProductBO;
import lombok.Data;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.stream.Collectors;

@Data
public class ProductServiceMapper {

    private ModelMapper modelMapper;

    public GetProductResponseDTO toGetProductResponseDTO(ProductBO bo) {
        return modelMapper.map(bo, GetProductResponseDTO.class);
    }

    public ProductBO toGetProductBO(ProductPO po) {
        return modelMapper.map(po, ProductBO.class);
    }

    public ProductBO toProductBO(ProductPO po) {
        return modelMapper.map(po, ProductBO.class);
    }

    public List<ProductBO> toProductBOList(List<ProductPO> poList) {
        return poList.stream()
                .map(this::toProductBO)
                .collect(Collectors.toList());
    }

    public QueryProductResponseDTO toQueryProductResponseDTO(List<ProductBO> boList) {
        QueryProductResponseDTO responseDTO = new QueryProductResponseDTO();
        List<QueryProductResponseDTO.ProductDetails> productDetails = boList.stream()
                .map(bo -> modelMapper.map(bo, QueryProductResponseDTO.ProductDetails.class))
                .collect(Collectors.toList());
        responseDTO.setProductDetails(productDetails);
        return responseDTO;
    }
}
