package com.example.sample.controller.bean.order;

import lombok.Data;

@Data
public class UpdateOrderRequestDTO {
    private int orderId;
    private int status;
    private String invoice;
}
