package com.example.sample.service;

import com.example.sample.controller.bean.cart.GetCartResponseDTO;
import com.example.sample.service.bean.CartBO;

public interface CartService {
    GetCartResponseDTO getCart(CartBO cartBO);
    void addCart(CartBO cartBO);
    void updateCart(CartBO cartBO);
    void deleteCart(CartBO cartBO);
}


