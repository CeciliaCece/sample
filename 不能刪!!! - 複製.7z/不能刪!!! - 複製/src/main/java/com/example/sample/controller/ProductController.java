package com.example.sample.controller;

import com.example.sample.constant.ReturnCode;
import com.example.sample.controller.bean.product.*;
import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.bean.base.RestRequest;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.controller.mapper.ProductControllerMapper;
import com.example.sample.service.ProductService;
import com.example.sample.utils.ResponseFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@RequestMapping("product/v1")
public class ProductController {

    @Autowired
    private ProductService productService;
    @Autowired
    private ProductControllerMapper mapper;

    @PostMapping(value = "/getProduct")
    public RestResponse<GetProductResponseDTO> getProduct(@Valid @RequestBody RestRequest<GetProductRequestDTO> request) {
        GetProductRequestDTO getProductRequestDTO = request.getBody();
        GetProductResponseDTO getProductResponseDTO = productService.getProduct(mapper.toGetProductRequestBO(getProductRequestDTO));
        return ResponseFactory.createSuccessResponse(getProductResponseDTO);
    }

    @PostMapping(value = "/queryProducts")
    public RestResponse<QueryProductResponseDTO> queryProducts() {
        QueryProductResponseDTO queryProductResponseDTOs = productService.queryProducts();
        return ResponseFactory.createSuccessResponse(queryProductResponseDTOs);
    }

    @PostMapping(value = "/addProduct")
    public RestResponse<ResultDTO> addProduct(@Valid @RequestBody RestRequest<AddProductRequestDTO> request) {
        AddProductRequestDTO addProductRequestDTO = request.getBody();
        productService.addProduct(mapper.toAddProductRequestBO(addProductRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Product added successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }

    @PostMapping(value = "/updateProduct")
    public RestResponse<ResultDTO> updateProduct(@Valid @RequestBody RestRequest<UpdateProductRequestDTO> request) {
        UpdateProductRequestDTO updateProductRequestDTO = request.getBody();
        productService.updateProduct(mapper.toUpdateProductRequestBO(updateProductRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Product updated successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }

    @PostMapping(value = "/deleteProduct")
    public RestResponse<ResultDTO> deleteProduct(@Valid @RequestBody RestRequest<DeleteProductRequestDTO> request) {
        DeleteProductRequestDTO deleteProductRequestDTO= request.getBody();
        productService.deleteProduct(mapper.toDeleteProductRequestBO(deleteProductRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Product deleted successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }
}