package com.example.sample.service;

import com.example.sample.controller.bean.product.GetProductResponseDTO;
import com.example.sample.controller.bean.product.QueryProductResponseDTO;
import com.example.sample.service.bean.ProductBO;



public interface ProductService {
    GetProductResponseDTO getProduct(ProductBO productBO);
    QueryProductResponseDTO queryProducts();
    void addProduct(ProductBO productBO);
    void updateProduct(ProductBO productBO);
    void deleteProduct(ProductBO productBO);
}