package com.example.sample.dao.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
public class ProductPO {
    private int productId;
    private String productName;
    private String description;
    private BigDecimal price;
    private int stock;
}