package com.example.sample.dao;

import com.example.sample.dao.bean.ProductPO;

import java.math.BigDecimal;
import java.util.List;

public interface ProductDao {
    ProductPO getProduct(int productId);
    List<ProductPO> queryProducts();
    void addProduct(String productName, String description, BigDecimal price, int stock);
    void updateProduct(int productId,String productName, String description, BigDecimal price,int stock);
    void deleteProduct(int productId);
}