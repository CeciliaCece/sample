package com.example.sample.controller;

import com.example.sample.constant.ReturnCode;
import com.example.sample.controller.bean.base.RestRequest;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.controller.bean.cart.*;
import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.mapper.CartControllerMapper;
import com.example.sample.service.CartService;
import com.example.sample.utils.ResponseFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@RequestMapping("cart/v1")
public class CartController {

    @Autowired
    private CartService cartService;
    @Autowired
    private CartControllerMapper mapper;

    @PostMapping(value = "/getCart")
    public RestResponse<GetCartResponseDTO> getCart(@Valid @RequestBody RestRequest<GetCartRequestDTO> request) {
        GetCartRequestDTO getCartRequestDTO = request.getBody();
        GetCartResponseDTO getCartResponseDTO = cartService.getCart(mapper.toGetCartRequestBO(getCartRequestDTO));
        return ResponseFactory.createSuccessResponse(getCartResponseDTO);
    }

    @PostMapping(value = "/addCart")
    public RestResponse<ResultDTO> addCart(@Valid @RequestBody RestRequest<AddCartRequestDTO> request) {
        AddCartRequestDTO addCartRequestDTO = request.getBody();
        cartService.addCart(mapper.toAddCartRequestBO(addCartRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Cart added successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }

    @PostMapping(value = "/updateCart")
    public RestResponse<ResultDTO> updateCart(@Valid @RequestBody RestRequest<UpdateCartRequestDTO> request) {
        UpdateCartRequestDTO updateCartRequestDTO = request.getBody();
        cartService.updateCart(mapper.toUpdateCartRequestBO(updateCartRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Cart updated successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }

    @PostMapping(value = "/deleteCart")
    public RestResponse<ResultDTO> deleteCart(@Valid @RequestBody RestRequest<DeleteCartRequestDTO> request) {
        DeleteCartRequestDTO deleteCartRequestDTO= request.getBody();
        cartService.deleteCart(mapper.toDeleteCartRequestBO(deleteCartRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Cart deleted successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }
}