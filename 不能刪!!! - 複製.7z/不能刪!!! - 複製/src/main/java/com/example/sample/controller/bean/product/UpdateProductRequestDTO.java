package com.example.sample.controller.bean.product;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class UpdateProductRequestDTO {
    private int productId;
    private String productName;
    private String description;
    private BigDecimal price;
    private int stock;
}
