package com.example.sample.controller.bean.cart;

import lombok.Data;

@Data
public class GetCartRequestDTO {
    private String username;
}
