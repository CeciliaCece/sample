package com.example.sample.controller;

import com.example.sample.annotation.SimpleLog;
import com.example.sample.controller.bean.sample.BankInfoDTO;
import com.example.sample.controller.bean.sample.BankParamDTO;
import com.example.sample.controller.bean.base.RestRequest;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.service.SampleService;
import com.example.sample.service.bean.BankInfoBO;
import com.example.sample.utils.ResponseFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("sample/v1")
public class SampleController {

    @Autowired
    private SampleService sampleService;

    @PostMapping(value="/getBankInfo")
    @PreAuthorize("hasRole('admin') or hasRole('user')")
    @SimpleLog
    public RestResponse<BankInfoDTO> getBankInfo(@Valid @RequestBody RestRequest<BankParamDTO> request) {

        BankParamDTO bankParamDTO = request.getBody();
        BankInfoDTO bankInfoDTO = sampleService.getBankInfo(BankInfoBO.createBy(bankParamDTO));

        return ResponseFactory.createSuccessResponse(bankInfoDTO);
    }



}