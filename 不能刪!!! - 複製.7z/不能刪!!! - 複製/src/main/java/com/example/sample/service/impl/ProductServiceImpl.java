package com.example.sample.service.impl;

import com.example.sample.controller.bean.product.GetProductResponseDTO;

import com.example.sample.controller.bean.product.QueryProductResponseDTO;
import com.example.sample.dao.ProductDao;
import com.example.sample.dao.bean.ProductPO;
import com.example.sample.service.ProductService;
import com.example.sample.service.bean.ProductBO;
import com.example.sample.service.mapper.ProductServiceMapper;
import lombok.Setter;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Setter
public class ProductServiceImpl implements ProductService {

    private ProductServiceMapper mapper;

    private ProductDao productDao;

    @Override
    @Transactional
    public GetProductResponseDTO getProduct(ProductBO productBO) {
        ProductPO productPO = productDao.getProduct(productBO.getProductId());
        return mapper.toGetProductResponseDTO(mapper.toGetProductBO(productPO));
    }

    @Override
    @Transactional
    public QueryProductResponseDTO queryProducts() {
        List<ProductPO> productPOs = productDao.queryProducts();
        return mapper.toQueryProductResponseDTO(mapper.toProductBOList(productPOs));
    }


    @Override
    @Transactional
    public void addProduct(ProductBO productBO) {
        productDao.addProduct(productBO.getProductName(),productBO.getDescription(),productBO.getPrice(),productBO.getStock());
    }

    @Override
    @Transactional
    public void updateProduct(ProductBO productBO) {
        productDao.updateProduct(productBO.getProductId(),productBO.getProductName(),productBO.getDescription(),productBO.getPrice(),productBO.getStock());
    }

    @Override
    @Transactional
    public void deleteProduct(ProductBO productBO) {
        productDao.deleteProduct(productBO.getProductId());
    }
}