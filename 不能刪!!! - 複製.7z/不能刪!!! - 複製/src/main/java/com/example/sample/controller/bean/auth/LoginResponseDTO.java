package com.example.sample.controller.bean.auth;

import lombok.Data;

@Data
public class LoginResponseDTO {
    private String lastName;
    private String token;
}
