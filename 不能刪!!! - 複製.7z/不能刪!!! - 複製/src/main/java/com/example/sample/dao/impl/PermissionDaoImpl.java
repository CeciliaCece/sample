package com.example.sample.dao.impl;

import com.example.sample.constant.ColConst;
import com.example.sample.constant.DbConst;
import com.example.sample.constant.ProcedureConst;
import com.example.sample.constant.ReturnCode;
import com.example.sample.dao.PermissionDao;
import com.example.sample.dao.bean.PermissionPO;
import com.example.sample.dao.mapper.PermissionMapper;
import com.example.sample.exception.SampleException;
import lombok.Data;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.sql.Types;
import java.util.List;
import java.util.Map;

@Data
public class PermissionDaoImpl implements PermissionDao {

    private JdbcTemplate jdbcTemplate;
    @Override
    public PermissionPO getRolesByPermissionName(String permissionName) {
        MapSqlParameterSource inSqlParms = new MapSqlParameterSource()
                .addValue(ColConst.I_PERMISSION_NAME, permissionName);

        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_G_PERMISSIONROLES)
                    .declareParameters(
                            new SqlParameter(ColConst.I_PERMISSION_NAME, Types.VARCHAR)
                    ).returningResultSet(ColConst.CURSOR, new PermissionMapper()).execute(inSqlParms);

            List<PermissionPO> result = (List<PermissionPO>) resultMap.get(ColConst.CURSOR);

            if (!result.isEmpty()) {
                return result.get(0);
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public List<PermissionPO> queryPermissions() {
        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_Q_PERMISSIONROLES)
                    .returningResultSet(ColConst.CURSOR, new PermissionMapper()).execute();
            List<PermissionPO> result = (List<PermissionPO>) resultMap.get(ColConst.CURSOR);

            if (!result.isEmpty()) {
                return result;
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public void updatePermission(int permissionId,List<Integer> permissionRolesId) {
        MapSqlParameterSource inSqlParms = new MapSqlParameterSource()
                .addValue(ColConst.I_PERMISSION_ID, permissionId)
                .addValue(ColConst.I_PERMISSION_ROLES_ID, permissionRolesId);

        try {
            new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_U_PERMISSIONROLES)
                    .declareParameters(
                            new SqlParameter(ColConst.I_PERMISSION_ID, Types.INTEGER),
                            new SqlParameter(ColConst.I_PERMISSION_ROLES_ID, Types.ARRAY)
                    ).execute(inSqlParms);

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

}
