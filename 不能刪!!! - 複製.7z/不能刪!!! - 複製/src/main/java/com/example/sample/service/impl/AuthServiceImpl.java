package com.example.sample.service.impl;

import com.example.sample.dao.AuthDao;
import com.example.sample.service.AuthService;
import com.example.sample.service.bean.AuthBO;
import com.example.sample.service.mapper.AuthServiceMapper;
import lombok.Setter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

@Setter
public class AuthServiceImpl implements AuthService {

    private AuthServiceMapper mapper;

    private AuthDao authDao;

    private BCryptPasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void register(AuthBO bo) {
        authDao.register(bo.getUsername(),passwordEncoder.encode(bo.getUserPassword()), bo.getLastName(),bo.getFirstName(),bo.getPhone(), 3);
    }
}
