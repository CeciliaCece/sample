package com.example.sample.service.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CartBO {
    private String username;
    private int productId;
    private int amount;
    private List<BuyListBO> buylist;
}
