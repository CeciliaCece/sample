package com.example.sample.service.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthBO {
    private String username;
    private String userPassword;
    private String lastName;
    private String firstName;
    private String phone;
}
