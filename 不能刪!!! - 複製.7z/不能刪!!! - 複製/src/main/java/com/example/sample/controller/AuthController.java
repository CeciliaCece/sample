package com.example.sample.controller;

import com.example.sample.constant.ReturnCode;
import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.bean.auth.RegisterRequestDTO;
import com.example.sample.controller.bean.base.RestRequest;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.controller.mapper.AuthControllerMapper;
import com.example.sample.service.AuthService;
import com.example.sample.utils.ResponseFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Collection;

@RestController
@RequestMapping("auth/v1")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private AuthControllerMapper mapper;

    @PostMapping(value = "/login")
    public String login(Authentication authentication) {
        String username = authentication.getName();
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        return "登入成功！帳號 " + username + " 的權限為: " + authorities;
    }

//    @PostMapping(value = "/login")
//    public RestResponse<LoginResponseDTO> login(@Valid @RequestBody RestRequest<LoginRequestDTO> request) {
//        LoginRequestDTO loginRequestDTO = request.getBody();
//        LoginResponseDTO loginResponseDTO = authService.login(mapper.toAuthBO(loginRequestDTO));
//        return ResponseFactory.createSuccessResponse(loginResponseDTO);
//    }

    @PostMapping(value = "/register")
    public RestResponse<ResultDTO> register(@Valid @RequestBody RestRequest<RegisterRequestDTO> request) {
        RegisterRequestDTO registerRequestDTO = request.getBody();
        authService.register(mapper.toAuthBO(registerRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("User registered successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }


}