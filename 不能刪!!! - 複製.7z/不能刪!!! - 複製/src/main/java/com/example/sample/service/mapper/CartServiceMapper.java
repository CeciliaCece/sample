package com.example.sample.service.mapper;

import com.example.sample.controller.bean.BuyListDTO;
import com.example.sample.controller.bean.cart.GetCartResponseDTO;
import com.example.sample.dao.bean.BuyListPO;
import com.example.sample.service.bean.BuyListBO;
import lombok.Data;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.stream.Collectors;

@Data
public class CartServiceMapper {

    private ModelMapper modelMapper;

    public BuyListBO toBuyListBO(BuyListPO buyListPO) {
        return modelMapper.map(buyListPO, BuyListBO.class);
    }

    public List<BuyListBO> toBuyListBOList(List<BuyListPO> buyListPOs) {
        return buyListPOs.stream().map(this::toBuyListBO).collect(Collectors.toList());
    }

    public BuyListDTO toBuyListDTO(BuyListBO buyListBO) {
        return modelMapper.map(buyListBO, BuyListDTO.class);
    }

    public List<BuyListDTO> toBuyListDTOList(List<BuyListBO> buyListBOs) {
        return buyListBOs.stream().map(this::toBuyListDTO).collect(Collectors.toList());
    }

    public GetCartResponseDTO toGetCartResponseDTO(List<BuyListBO> buyListBOs) {
        List<BuyListDTO> buyListDTOs = toBuyListDTOList(buyListBOs);
        return new GetCartResponseDTO(buyListDTOs);
    }
}
