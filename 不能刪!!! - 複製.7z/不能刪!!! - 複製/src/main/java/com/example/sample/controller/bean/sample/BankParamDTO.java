package com.example.sample.controller.bean.sample;

import lombok.Data;

@Data
public class BankParamDTO {
    private String bankCode;

    private String bankName;

    private String branchCode;

    private String branchName;
}