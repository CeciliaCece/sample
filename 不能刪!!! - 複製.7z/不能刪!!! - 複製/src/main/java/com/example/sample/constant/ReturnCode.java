package com.example.sample.constant;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum ReturnCode {
    SUCCESS("0000", "Success."),
    DB_ERROR("9999", "DB ERROR."),
    RESPONSE_NOT_FOUND("9998","Response not found."),
    DATA_NOT_FOUND("9997","Data not found."),
    AUTH_ERROR("4444","AUTH ERROR"),
    PERMISSION_DENIED("4403", "Permission Denied"),
    UNAUTHORIZED("4401", "UnAuthorized")
    ;

    private String code;
    private String value;


    ReturnCode(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public static ReturnCode getById(String code) {
        return Arrays.stream(ReturnCode.values())
                .filter(returnCode -> returnCode.code.equals(code))
                .findAny()
                .get();
    }
}