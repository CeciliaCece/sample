package com.example.sample.service.bean;

import com.example.sample.controller.bean.sample.BankInfoDTO;
import com.example.sample.controller.bean.sample.BankParamDTO;
import com.example.sample.dao.bean.BankInfoPO;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BankInfoBO {
    private String bankCode;
    private String bankName;
    private String branchCode;
    private String branchName;

    public static BankInfoBO createBy(BankParamDTO dto) {
        return BankInfoBO.builder()
                .bankCode(dto.getBankCode())
                .bankName(dto.getBankName())
                .branchCode(dto.getBranchCode())
                .branchName(dto.getBranchName())
                .build();
    }

    public BankInfoDTO getBankInfoDTO() {
        return BankInfoDTO.builder()
                .bankCode(this.bankCode)
                .bankName(this.bankName)
                .branchCode(this.branchCode)
                .branchName(this.branchName)
                .build();
    }

    public static BankInfoBO createBy(BankInfoPO po) {
        return BankInfoBO.builder()
                .bankCode(po.getBankCode())
                .bankName(po.getBankName())
                .branchCode(po.getBranchCode())
                .branchName(po.getBranchName())
                .build();
    }
}