package com.example.sample.dao;

import com.example.sample.dao.bean.PermissionPO;

import java.util.List;

public interface PermissionDao {
    PermissionPO getRolesByPermissionName(String permissionName);
    List<PermissionPO> queryPermissions();
    void updatePermission(int permissionId,List<Integer> permissionRolesId);

}
