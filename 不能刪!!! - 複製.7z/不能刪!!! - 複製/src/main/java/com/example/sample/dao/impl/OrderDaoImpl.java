package com.example.sample.dao.impl;

import com.example.sample.constant.ColConst;
import com.example.sample.constant.DbConst;
import com.example.sample.constant.ProcedureConst;
import com.example.sample.constant.ReturnCode;
import com.example.sample.dao.OrderDao;
import com.example.sample.dao.bean.OrderPO;
import com.example.sample.dao.mapper.OrderMapper;
import com.example.sample.exception.SampleException;
import lombok.Data;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.sql.Types;
import java.util.List;
import java.util.Map;

@Data
public class OrderDaoImpl implements OrderDao {

    private JdbcTemplate jdbcTemplate;
    
    @Override
    public List<OrderPO> queryOrders() {
        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_Q_ORDER)
                    .returningResultSet(ColConst.CURSOR, new OrderMapper()).execute();
            List<OrderPO> result = (List<OrderPO>) resultMap.get(ColConst.CURSOR);

            if (!result.isEmpty()) {
                return result;
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public List<OrderPO> getOrders(String username) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_USERNAME, username);
        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_G_ORDER)
                    .declareParameters(
                            new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR))
                    .returningResultSet(ColConst.CURSOR, new OrderMapper())
                    .execute(in);
            List<OrderPO> result = (List<OrderPO>) resultMap.get(ColConst.CURSOR);

            if (!result.isEmpty()) {
                return result;
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public void addOrder(String username ,String orderDate, String invoice) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_USERNAME, username)
                .addValue(ColConst.I_ORDER_DATE, orderDate)
                .addValue(ColConst.I_INVOICE, invoice);

        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_C_ORDER)
                    .declareParameters(
                            new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_ORDER_DATE, Types.VARCHAR),
                            new SqlParameter(ColConst.I_INVOICE, Types.VARCHAR)
                    ).execute(in);

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }

    }

    @Override
    public void updateOrder(int orderId, int status, String invoice) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_ORDER_ID, orderId)
                .addValue(ColConst.I_STATUS, status)
                .addValue(ColConst.I_INVOICE, invoice);

        try {
            new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_U_ORDER)
                    .declareParameters(
                            new SqlParameter(ColConst.I_ORDER_ID, Types.INTEGER),
                            new SqlParameter(ColConst.I_STATUS, Types.INTEGER),
                            new SqlParameter(ColConst.I_INVOICE, Types.VARCHAR)
                    ).execute(in);
        } catch (Exception e) {

            throw new SampleException(ReturnCode.DB_ERROR, e);
        }

    }
}
