package com.example.sample.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
public class TestController {

    @PostMapping(value = "/unknown")
    public String getUnknown(Authentication authentication) {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        return "權限為: " + authorities;
    }

    @PostMapping(value = "/customer")
    public String getUser(Authentication authentication) {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        return "權限為: " + authorities;
    }

    @PostMapping(value = "/manager")
    public String getManager(Authentication authentication) {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        return "權限為: " + authorities;
    }

    @PostMapping(value = "/admin")
    public String getAdmin(Authentication authentication) {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        return "權限為: " + authorities;
    }

}
