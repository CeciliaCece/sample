package com.example.sample.dao;

import com.example.sample.dao.bean.OrderPO;

import java.util.List;

public interface OrderDao {

    List<OrderPO> queryOrders();
    List<OrderPO> getOrders(String username);
    void addOrder(String username ,String date, String invoice);
    void updateOrder(int orderId, int status, String invoice);

}
