package com.example.sample.dao.mapper;

import com.example.sample.constant.DbConst;
import com.example.sample.dao.bean.ProductPO;
import com.example.sample.utils.ResultSetUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductMapper implements RowMapper<ProductPO> {

    @Override
    public ProductPO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return ProductPO.builder()
                .productId(ResultSetUtil.getIntSafe(rs, DbConst.TB_PRODUCT_PRODUCT_ID))
                .productName(ResultSetUtil.getStringSafe(rs, DbConst.TB_PRODUCT_PRODUCT_NAME))
                .description(ResultSetUtil.getStringSafe(rs, DbConst.TB_PRODUCT_DESCRIPTION))
                .price(ResultSetUtil.getBigDecimalSafe(rs, DbConst.TB_PRODUCT_PRICE))
                .stock(ResultSetUtil.getIntSafe(rs, DbConst.TB_PRODUCT_STOCK))
                .build();
    }
}
