package com.example.sample.service;

import com.example.sample.controller.bean.order.GetOrderResponseDTO;
import com.example.sample.controller.bean.order.QueryOrderResponseDTO;
import com.example.sample.service.bean.OrderBO;

public interface OrderService {
    QueryOrderResponseDTO queryOrders();
    GetOrderResponseDTO getOrders(OrderBO orderBO);
    void addOrder(OrderBO orderBO);
    void updateOrder(OrderBO orderBO);
}
