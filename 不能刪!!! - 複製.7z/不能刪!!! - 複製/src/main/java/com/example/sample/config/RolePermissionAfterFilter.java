package com.example.sample.config;

import com.example.sample.constant.ReturnCode;
import com.example.sample.dao.bean.PermissionPO;
import com.example.sample.exception.SampleException;
import com.example.sample.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class RolePermissionAfterFilter extends OncePerRequestFilter {

    @Autowired
    private PermissionService permissionService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        System.out.println("RolePermissionAfterFilter");
        String path = request.getServletPath();
        PermissionPO permissionPO = permissionService.getRolesByPermissionName(path);
        List<String> permissionRoles = permissionPO.getPermissionRoles();

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        List<String> userRoles = auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());

        if(!permissionRoles.contains(userRoles.get(0))){
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            request.setAttribute("SampleException", new SampleException(ReturnCode.PERMISSION_DENIED));
            throw new SampleException(ReturnCode.PERMISSION_DENIED);
        }
        filterChain.doFilter(request, response);
    }

}
