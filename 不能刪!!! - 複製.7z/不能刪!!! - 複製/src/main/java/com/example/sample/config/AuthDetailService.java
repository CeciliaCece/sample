package com.example.sample.config;

import com.example.sample.dao.AuthDao;
import com.example.sample.dao.bean.AuthPO;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class AuthDetailService implements UserDetailsService {

    private final Logger LOG = Logger.getLogger(AuthDetailService.class.getName());

    @Setter
    private AuthDao authDao;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AuthPO authPO = authDao.getUserInfoByUsername(username);

        if (authPO == null) {
            throw new UsernameNotFoundException("User not found for: " + username);
        } else {
            String authPassword = authPO.getUserPassword();
            String authUsername = authPO.getUsername();

            List<GrantedAuthority> authorities = new ArrayList<>();
            authorities.add(new SimpleGrantedAuthority(authPO.getUserRole()));
            LOG.info("UserRole : " + authPO.getUserRole());

            return new AuthUser(authUsername, authPassword, authorities);
        }
    }

    private static class AuthUser extends User {
        private static final long serialVersionUID = 1L;

        public AuthUser(String username, String password, List<GrantedAuthority> authorities) {
            super(username, password, authorities);
        }
    }
}