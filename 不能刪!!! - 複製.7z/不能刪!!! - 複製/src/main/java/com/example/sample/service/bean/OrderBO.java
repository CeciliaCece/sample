package com.example.sample.service.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderBO {
    private int orderId;
    private String username;
    private String orderDate;
    private int status;
    private String invoice;
    private List<BuyListBO> buylist;
}
