package com.example.sample.dao.impl;

import com.example.sample.constant.ColConst;
import com.example.sample.constant.DbConst;
import com.example.sample.constant.ProcedureConst;
import com.example.sample.constant.ReturnCode;
import com.example.sample.dao.AuthDao;
import com.example.sample.dao.bean.AuthPO;
import com.example.sample.dao.mapper.AuthMapper;
import com.example.sample.exception.SampleException;
import lombok.Data;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.sql.Types;
import java.util.List;
import java.util.Map;

@Data
public class AuthDaoImpl implements AuthDao {

    private JdbcTemplate jdbcTemplate;

    @Override
    public AuthPO getUserInfoByUsername(String username) {

        MapSqlParameterSource inSqlParms = new MapSqlParameterSource()
                .addValue(ColConst.I_USERNAME, username);

        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_G_USERINFO)
                    .declareParameters(
                            new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR)
                    ).returningResultSet(ColConst.CURSOR, new AuthMapper()).execute(inSqlParms);

            List<AuthPO> result = (List<AuthPO>) resultMap.get(ColConst.CURSOR);
            if (result.size() > 0) {
                return result.get(0);
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public void register(String username, String userPassword, String lastName, String firstName, String phone, int userRole) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_USERNAME, username)
                .addValue(ColConst.I_USER_PASSWORD, userPassword)
                .addValue(ColConst.I_LAST_NAME, lastName)
                .addValue(ColConst.I_FIRST_NAME, firstName)
                .addValue(ColConst.I_PHONE, phone)
                .addValue(ColConst.I_USER_ROLE, userRole);

        try {
            new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_C_USERINFO)
                    .declareParameters(
                            new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_USER_PASSWORD, Types.VARCHAR),
                            new SqlParameter(ColConst.I_LAST_NAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_FIRST_NAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_PHONE, Types.VARCHAR),
                            new SqlParameter(ColConst.I_USER_ROLE, Types.INTEGER)
                    ).execute(in);
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }
}
