package com.example.sample.dao.mapper;

import com.example.sample.dao.bean.BankInfoPO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.example.sample.constant.DbConst.TB_BANKINFO_BANK_CODE;
import static com.example.sample.constant.DbConst.TB_BANKINFO_BANK_NAME;
import static com.example.sample.constant.DbConst.TB_BANKINFO_BRANCH_CODE;
import static com.example.sample.constant.DbConst.TB_BANKINFO_BRANCH_NAME;

public class BankInfoMapper implements RowMapper<BankInfoPO> {

    @Override
    public BankInfoPO mapRow(ResultSet resultSet, int i) throws SQLException {
        return BankInfoPO.builder()
                .bankCode(resultSet.getString(TB_BANKINFO_BANK_CODE))
                .bankName(resultSet.getString(TB_BANKINFO_BANK_NAME))
                .branchCode(resultSet.getString(TB_BANKINFO_BRANCH_CODE))
                .branchName(resultSet.getString(TB_BANKINFO_BRANCH_NAME))
                .build();
    }
}