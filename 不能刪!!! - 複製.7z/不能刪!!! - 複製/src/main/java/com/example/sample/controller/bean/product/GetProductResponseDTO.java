package com.example.sample.controller.bean.product;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class GetProductResponseDTO {
    private String productName;
    private String description;
    private BigDecimal price;
    private int stock;
}
