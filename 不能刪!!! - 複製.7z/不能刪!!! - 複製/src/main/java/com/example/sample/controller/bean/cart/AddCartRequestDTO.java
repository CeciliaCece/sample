package com.example.sample.controller.bean.cart;

import lombok.Data;

@Data
public class AddCartRequestDTO {
    private String username;
    private int productId;
    private int amount;
}
