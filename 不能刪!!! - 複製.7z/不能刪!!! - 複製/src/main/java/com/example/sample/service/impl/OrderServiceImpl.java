package com.example.sample.service.impl;

import com.example.sample.controller.bean.order.GetOrderResponseDTO;
import com.example.sample.controller.bean.order.QueryOrderResponseDTO;
import com.example.sample.dao.BuyListDao;
import com.example.sample.dao.OrderDao;
import com.example.sample.dao.bean.BuyListPO;
import com.example.sample.dao.bean.OrderPO;
import com.example.sample.service.OrderService;
import com.example.sample.service.bean.BuyListBO;
import com.example.sample.service.bean.OrderBO;
import com.example.sample.service.mapper.OrderServiceMapper;
import lombok.Setter;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Setter
public class OrderServiceImpl implements OrderService {

    private OrderServiceMapper mapper;

    private OrderDao orderDao;

    private BuyListDao buyListDao;

    @Override
    @Transactional
    public QueryOrderResponseDTO queryOrders() {
        List<OrderPO> orderPOs = orderDao.queryOrders();
        List<OrderBO> orderBOs = mapper.toOrderBOList(orderPOs);

        for (OrderBO orderBO : orderBOs) {
            List<BuyListPO> buyListPOs = buyListDao.getBuyLists(orderBO.getOrderId());
            List<BuyListBO> buyListDetails = mapper.toBuyListDetails(buyListPOs);

            orderBO.setBuylist(buyListDetails);
        }

        return mapper.toQueryOrderResponseDTO(orderBOs);
    }

    @Override
    @Transactional
    public GetOrderResponseDTO getOrders(OrderBO bo) {
        List<OrderPO> orderPOs = orderDao.getOrders(bo.getUsername());
        List<OrderBO> orderBOs = mapper.toOrderBOList(orderPOs);

        for (OrderBO orderBO : orderBOs) {
            List<BuyListPO> buyListPOs = buyListDao.getBuyLists(orderBO.getOrderId());
            List<BuyListBO> buyListDetails = mapper.toBuyListDetails(buyListPOs);

            orderBO.setBuylist(buyListDetails);
        }
        return mapper.toGetOrderResponseDTO(orderBOs);
    }

    @Override
    @Transactional
    public void addOrder(OrderBO orderBO) {
        orderDao.addOrder(orderBO.getUsername(),orderBO.getOrderDate(),orderBO.getInvoice());
    }

    @Override
    @Transactional
    public void updateOrder(OrderBO orderBO) {
        orderDao.updateOrder(orderBO.getOrderId(),orderBO.getStatus(),orderBO.getInvoice());
    }

}
