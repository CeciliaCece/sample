package com.example.sample.dao.bean;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AuthPO {
    private String username;
    private String userPassword;
    private String lastName;
    private String firstName;
    private String phone;
    private String userRole;
}
