package com.example.sample.dao.impl;

import com.example.sample.constant.ColConst;
import com.example.sample.constant.DbConst;
import com.example.sample.constant.ProcedureConst;
import com.example.sample.constant.ReturnCode;
import com.example.sample.dao.ProductDao;
import com.example.sample.dao.bean.ProductPO;
import com.example.sample.dao.mapper.ProductMapper;
import com.example.sample.exception.SampleException;
import lombok.Data;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Data
public class ProductDaoImpl implements ProductDao {

    private JdbcTemplate jdbcTemplate;

    @Override
    public void addProduct(String productName, String description, BigDecimal price, int stock) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_PRODUCT_NAME, productName)
                .addValue(ColConst.I_DESCRIPTION, description)
                .addValue(ColConst.I_PRICE, price)
                .addValue(ColConst.I_STOCK, stock);

        try {
            new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_C_PRODUCT)
                    .declareParameters(
                            new SqlParameter(ColConst.I_PRODUCT_NAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_DESCRIPTION, Types.VARCHAR),
                            new SqlParameter(ColConst.I_PRICE, Types.NUMERIC),
                            new SqlParameter(ColConst.I_STOCK, Types.INTEGER)
                    ).execute(in);
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public void deleteProduct(int productId) {
        MapSqlParameterSource inSqlParms = new MapSqlParameterSource()
                .addValue(ColConst.I_PRODUCT_ID, productId);

        try {
                new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_D_PRODUCT)
                    .declareParameters(
                            new SqlParameter(ColConst.I_PRODUCT_ID, Types.INTEGER)
                    ).execute(inSqlParms);

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public void updateProduct(int productId, String productName, String description, BigDecimal price, int stock) {
        MapSqlParameterSource inSqlParms = new MapSqlParameterSource()
                .addValue(ColConst.I_PRODUCT_ID, productId)
                .addValue(ColConst.I_PRODUCT_NAME, productName)
                .addValue(ColConst.I_DESCRIPTION, description)
                .addValue(ColConst.I_PRICE, price)
                .addValue(ColConst.I_STOCK, stock);

        try {
            new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_U_PRODUCT)
                    .declareParameters(
                            new SqlParameter(ColConst.I_PRODUCT_ID, Types.INTEGER),
                            new SqlParameter(ColConst.I_PRODUCT_NAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_DESCRIPTION, Types.VARCHAR),
                            new SqlParameter(ColConst.I_PRICE, Types.NUMERIC),
                            new SqlParameter(ColConst.I_STOCK, Types.INTEGER)
                    ).execute(inSqlParms);

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public ProductPO getProduct(int productId) {
        MapSqlParameterSource inSqlParms = new MapSqlParameterSource()
                .addValue(ColConst.I_PRODUCT_ID, productId);

        try {Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_G_PRODUCT)
                    .declareParameters(
                            new SqlParameter(ColConst.I_PRODUCT_ID, Types.INTEGER)
                    ).returningResultSet(ColConst.CURSOR, new ProductMapper()).execute(inSqlParms);

            List<ProductPO> result = (List<ProductPO>) resultMap.get(ColConst.CURSOR);

            if (!result.isEmpty()) {
                return result.get(0);
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }

    @Override
    public List<ProductPO> queryProducts() {
        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_Q_PRODUCT)
                    .returningResultSet(ColConst.CURSOR, new ProductMapper()).execute();
            List<ProductPO> result = (List<ProductPO>) resultMap.get(ColConst.CURSOR);

            if (!result.isEmpty()) {
                return result;
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }
        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }
    }
}