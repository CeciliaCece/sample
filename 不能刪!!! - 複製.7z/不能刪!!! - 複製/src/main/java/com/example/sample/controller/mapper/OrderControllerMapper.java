package com.example.sample.controller.mapper;

import com.example.sample.controller.bean.order.AddOrderRequestDTO;
import com.example.sample.controller.bean.order.GetOrderRequestDTO;
import com.example.sample.controller.bean.order.UpdateOrderRequestDTO;
import com.example.sample.service.bean.OrderBO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderControllerMapper {
    @Autowired
    ModelMapper modelMapper;


    public OrderBO toAddOrderRequestBO(AddOrderRequestDTO addOrderRequestDTO) {
        return modelMapper.map(addOrderRequestDTO, OrderBO.class);
    }

    public OrderBO toUpdateOrderRequestBO(UpdateOrderRequestDTO updateOrderRequestDTO) {
        return modelMapper.map(updateOrderRequestDTO, OrderBO.class);
    }

    public OrderBO toGetOrderRequestBO(GetOrderRequestDTO getOrderRequestDTO) {
        return modelMapper.map(getOrderRequestDTO, OrderBO.class);
    }

}
