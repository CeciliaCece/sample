package com.example.sample.service;

import com.example.sample.controller.bean.permission.QueryPermissionResponseDTO;
import com.example.sample.dao.bean.PermissionPO;
import com.example.sample.service.bean.PermissionBO;

public interface PermissionService {
    PermissionPO getRolesByPermissionName(String permissionName);
    QueryPermissionResponseDTO queryPermissions();

    void updatePermission(PermissionBO permissionBO);

}
