package com.example.sample.controller.bean.sample;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BankInfoDTO {
    private String bankCode;
    private String bankName;
    private String branchCode;
    private String branchName;
}