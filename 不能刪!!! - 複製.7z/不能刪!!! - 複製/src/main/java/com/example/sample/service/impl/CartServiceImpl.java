package com.example.sample.service.impl;

import com.example.sample.controller.bean.cart.GetCartResponseDTO;
import com.example.sample.dao.CartDao;
import com.example.sample.dao.bean.BuyListPO;
import com.example.sample.service.CartService;
import com.example.sample.service.bean.BuyListBO;
import com.example.sample.service.bean.CartBO;
import com.example.sample.service.mapper.CartServiceMapper;
import lombok.Setter;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Setter
public class CartServiceImpl implements CartService {

    private CartServiceMapper mapper;

    private CartDao cartDao;


    @Override
    @Transactional
    public GetCartResponseDTO getCart(CartBO cartBO) {
        List<BuyListPO> buyListPOs = cartDao.getCart(cartBO.getUsername());
        List<BuyListBO> buyListBOs = mapper.toBuyListBOList(buyListPOs);
        return mapper.toGetCartResponseDTO(buyListBOs);
    }

    @Override
    @Transactional
    public void addCart(CartBO cartBO) {
        cartDao.addCart(cartBO.getUsername(),cartBO.getProductId(),cartBO.getAmount());
    }

    @Override
    @Transactional
    public void updateCart(CartBO cartBO) {
        cartDao.updateCart(cartBO.getUsername(),cartBO.getProductId(),cartBO.getAmount());
    }

    @Override
    @Transactional
    public void deleteCart(CartBO cartBO) {
        cartDao.deleteCart(cartBO.getUsername(),cartBO.getProductId());
    }
}
