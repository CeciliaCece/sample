package com.example.sample.config;

import com.example.sample.constant.ReturnCode;
import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.exception.SampleException;
import com.example.sample.utils.ResponseFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException {
        SampleException sampleException = (SampleException) request.getAttribute("SampleException");
        if (sampleException != null) {
            createErrorResponse(response, sampleException);
        } else {
            SampleException defaultException = new SampleException(ReturnCode.UNAUTHORIZED);
            createErrorResponse(response, defaultException);
        }
    }

    private void createErrorResponse(HttpServletResponse response, Exception cause) throws IOException {
        response.setStatus(HttpServletResponse.SC_OK);
        response.setContentType("application/json");
        RestResponse<ResultDTO> errorResponse =
                ResponseFactory.createErrorResponse(ReturnCode.AUTH_ERROR.getCode(), ReturnCode.AUTH_ERROR.getValue(), cause);
        PrintWriter writer = response.getWriter();
        writer.write(convertObjectToJson(errorResponse));
        writer.flush();
        writer.close();
    }

    private String convertObjectToJson(Object object) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(object);
        } catch (IOException e) {
            throw new RuntimeException("Error converting object to JSON", e);
        }
    }
}