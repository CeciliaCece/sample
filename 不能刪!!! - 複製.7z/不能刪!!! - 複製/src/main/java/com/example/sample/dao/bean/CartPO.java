package com.example.sample.dao.bean;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class CartPO {
    private String username;
    private int productId;
    private int amount;
    private List<BuyListPO> buylist;
}
