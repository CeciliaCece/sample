package com.example.sample.config;

import com.example.sample.constant.ReturnCode;
import com.example.sample.constant.SecurityConstant;
import com.example.sample.dao.bean.PermissionPO;
import com.example.sample.exception.SampleException;
import com.example.sample.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collection;
import java.util.stream.Collectors;

import static com.example.sample.constant.SecurityConstant.ROLE_UNKNOWN;

@Component
public class RolePermissionBeforeFilter extends OncePerRequestFilter {

    @Autowired
    private PermissionService permissionService;


    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        System.out.println("RolePermissionBeforeFilter");
        Authentication JwtAuth = SecurityContextHolder.getContext().getAuthentication();
        String headerAuth = request.getHeader(SecurityConstant.AUTH_HEADER);
        String path = request.getServletPath();
        PermissionPO permissionPO = permissionService.getRolesByPermissionName(path);

        //需要寫死的權限
        if (headerAuth == null && PermissionChecker(permissionPO, ROLE_UNKNOWN)) {
            Authentication auth = new UsernamePasswordAuthenticationToken(ROLE_UNKNOWN, null,
                    AuthorityUtils.commaSeparatedStringToAuthorityList(ROLE_UNKNOWN));
            SecurityContextHolder.getContext().setAuthentication(auth);
        }

        if (JwtAuth != null){
            Collection<? extends GrantedAuthority> jwtRole = JwtAuth.getAuthorities();
            if(!PermissionChecker(permissionPO,ConvertAuthoritiesToString(jwtRole))){
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                request.setAttribute("SampleException", new SampleException(ReturnCode.PERMISSION_DENIED));
                throw new SampleException(ReturnCode.PERMISSION_DENIED);
            }
        }
            filterChain.doFilter(request, response);
    }

    private boolean PermissionChecker(PermissionPO permissionPO, String role) {
        if (permissionPO.getPermissionRoles().contains(role)) {
            return true;
        }
        return false;
    }

    private String ConvertAuthoritiesToString(Collection<? extends GrantedAuthority> authorities) {
        return authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(", "));
    }
}
