package com.example.sample.controller.mapper;

import com.example.sample.controller.bean.auth.LoginRequestDTO;
import com.example.sample.controller.bean.auth.RegisterRequestDTO;
import com.example.sample.controller.bean.product.AddProductRequestDTO;
import com.example.sample.service.bean.AuthBO;
import com.example.sample.service.bean.ProductBO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AuthControllerMapper {
    @Autowired
    ModelMapper modelMapper;

    public AuthBO toAuthBO(LoginRequestDTO loginRequestDTO) {
        return modelMapper.map(loginRequestDTO, AuthBO.class);
    }

    public AuthBO toAuthBO(RegisterRequestDTO registerRequestDTO) {
        return modelMapper.map(registerRequestDTO, AuthBO.class);
    }
}
