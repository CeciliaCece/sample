package com.example.sample.service.mapper;

import com.example.sample.controller.bean.permission.QueryPermissionResponseDTO;
import com.example.sample.dao.bean.PermissionPO;
import com.example.sample.service.bean.PermissionBO;
import lombok.Data;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.stream.Collectors;

@Data
public class PermissionServiceMapper {

    private ModelMapper modelMapper;

    public PermissionBO toPermissionBO(PermissionPO po) {
        return modelMapper.map(po, PermissionBO.class);
    }

    public List<PermissionBO> toPermissionBOList(List<PermissionPO> poList) {
        return poList.stream()
                .map(this::toPermissionBO)
                .collect(Collectors.toList());
    }

    public QueryPermissionResponseDTO toQueryPermissionResponseDTO(List<PermissionBO> boList) {
        QueryPermissionResponseDTO responseDTO = new QueryPermissionResponseDTO();
        List<QueryPermissionResponseDTO.PermissionDetails> permissionDetails = boList.stream()
                .map(bo -> modelMapper.map(bo, QueryPermissionResponseDTO.PermissionDetails.class))
                .collect(Collectors.toList());
        responseDTO.setPermissionsDetails(permissionDetails);
        return responseDTO;
    }
}
