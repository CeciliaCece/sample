package com.example.sample.utils;

import com.example.sample.constant.ReturnCode;
import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.exception.SampleException;

public class ResponseFactory {

    public static <Body> RestResponse<Body> createResponse(String code, String desc, Body body) {
        RestResponse<Body> restResponse = new RestResponse<>();

        RestResponse.ResponseHeader header = new RestResponse.ResponseHeader();
        header.setResultCode(code);
        header.setResultDescription(desc);
        restResponse.setHeader(header);
        restResponse.setBody(body);


        return restResponse;
    }

    public static <Body>RestResponse<Body> createSuccessResponse(Body body) {

        ReturnCode returnCode = ReturnCode.SUCCESS;
        RestResponse<Body> restResponse = createResponse(returnCode.getCode(), returnCode.getValue(), body);

        return restResponse;
    }

    public static RestResponse<ResultDTO> createErrorResponse(String code, String desc,Throwable cause) {

        ResultDTO resultDTO = new ResultDTO();

        if (cause instanceof SampleException) {
            SampleException sampleException = (SampleException) cause;
            resultDTO.setResultCode(sampleException.getReturnCode().getCode());
            resultDTO.setResultDescription(sampleException.getReturnCode().getValue());
        } else {
            resultDTO.setResultCode(code);
            resultDTO.setResultDescription(desc);
        }

        RestResponse<ResultDTO> response = createResponse(code, desc, resultDTO);

        return response;
    }
}