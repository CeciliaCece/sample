package com.example.sample.service;

import com.example.sample.service.bean.AuthBO;

public interface AuthService {
    void register(AuthBO bo);
}
