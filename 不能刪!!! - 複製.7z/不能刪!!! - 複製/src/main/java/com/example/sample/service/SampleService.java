package com.example.sample.service;

import com.example.sample.controller.bean.sample.BankInfoDTO;
import com.example.sample.service.bean.BankInfoBO;

public interface SampleService {
    BankInfoDTO getBankInfo(BankInfoBO bo);
}