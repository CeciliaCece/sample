package com.example.sample.dao.mapper;

import com.example.sample.constant.DbConst;
import com.example.sample.dao.bean.OrderPO;
import com.example.sample.utils.ResultSetUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderMapper implements RowMapper<OrderPO> {

    @Override
    public OrderPO mapRow(ResultSet rs, int i) throws SQLException {
        return OrderPO.builder()
                .orderId(ResultSetUtil.getIntSafe(rs, DbConst.TB_ORDER_ORDER_ID))
                .username(ResultSetUtil.getStringSafe(rs, DbConst.TB_ORDER_USERNAME))
                .orderDate(ResultSetUtil.getStringSafe(rs, DbConst.TB_ORDER_DATE))
                .status(ResultSetUtil.getIntSafe(rs, DbConst.TB_ORDER_STATUS))
                .invoice(ResultSetUtil.getStringSafe(rs, DbConst.TB_ORDER_INVOICE))
                .build();
    }
}
