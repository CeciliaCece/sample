package com.example.sample.controller.bean.cart;

import lombok.Data;

@Data
public class DeleteCartRequestDTO {
    private String username;
    private int productId;
}
