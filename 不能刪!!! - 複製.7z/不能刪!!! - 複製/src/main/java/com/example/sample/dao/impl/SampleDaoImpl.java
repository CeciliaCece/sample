package com.example.sample.dao.impl;

import com.example.sample.constant.ReturnCode;
import com.example.sample.dao.SampleDao;
import com.example.sample.dao.bean.BankInfoPO;
import com.example.sample.dao.mapper.BankInfoMapper;
import com.example.sample.exception.SampleException;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.sql.Types;
import java.util.List;
import java.util.Map;

@Data
public class SampleDaoImpl implements SampleDao {
    private static final Logger LOG = LogManager.getLogger(SampleDaoImpl.class.getName());

    private JdbcTemplate jdbcTemplate;

    @Override
    public BankInfoPO getBankInfo(String bankCode, String branchCode) {

        try {
            SimpleJdbcCall callGetBusinessData = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName("esbedu")
                    .withProcedureName("sp_get_branchinfo")
                    .withoutProcedureColumnMetaDataAccess()
                    .declareParameters(
                            new SqlParameter("i_bank_code", Types.VARCHAR),
                            new SqlParameter("i_branch_code", Types.VARCHAR)
                    ).returningResultSet("data", new BankInfoMapper());

            MapSqlParameterSource inSqlParms = new MapSqlParameterSource()  // 映射SQL參數
                    .addValue("i_bank_code", bankCode)
                    .addValue("i_branch_code", branchCode);
            Map<String, Object> resultMap = callGetBusinessData.execute(inSqlParms);
            List<BankInfoPO> result = (List<BankInfoPO>) resultMap.get("data");

            if (result.size() != 0) {
                return result.get(0);
            } else {
                throw new SampleException(ReturnCode.DATA_NOT_FOUND);
            }

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }

    }
}