package com.example.sample.dao;

import com.example.sample.dao.bean.AuthPO;

public interface AuthDao {
    AuthPO getUserInfoByUsername(String username);
    void register(String username, String userPassword, String lastName, String firstName, String phone, int userRole);
}
