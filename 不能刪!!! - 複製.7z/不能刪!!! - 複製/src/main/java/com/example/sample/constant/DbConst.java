package com.example.sample.constant;
public class DbConst {

    public static final String SCHEMA_TRAVEL_TOGETHER = "traveltogether";

    public static final String TB_PRODUCT_PRODUCT_ID = "product_id";
    public static final String TB_PRODUCT_PRODUCT_NAME = "product_name";
    public static final String TB_PRODUCT_DESCRIPTION = "description";
    public static final String TB_PRODUCT_PRICE = "price";
    public static final String TB_PRODUCT_STOCK = "stock";

    public static final String TB_USERINFO_USERNAME = "username";
    public static final String TB_USERINFO_USER_PASSWORD = "user_password";
    public static final String TB_USERINFO_LAST_NAME = "last_name";
    public static final String TB_USERINFO_FIRST_NAME = "first_name";
    public static final String TB_USERINFO_PHONE = "phone";
    public static final String TB_USERINFO_USER_ROLE = "user_role";


    public static final String SCHEMA_ESBEDU = "esbedu";

    public static final String TB_BANKINFO_BANK_CODE = "bank_code";
    public static final String TB_BANKINFO_BANK_NAME = "bank_name";
    public static final String TB_BANKINFO_BRANCH_CODE = "branch_code";
    public static final String TB_BANKINFO_BRANCH_NAME = "branch_name";

    public static final String TB_PERMISSIONROLES_PERMISSION_ID = "permission_id";
    public static final String TB_PERMISSIONROLES_PERMISSION_NAME = "permission_name";
    public static final String TB_PERMISSIONROLES_PERMISSION_CNAME = "permission_cname";
    public static final String TB_PERMISSIONROLES_PERMISSION_ROLES = "permission_roles";
    public static final String TB_PERMISSIONROLES_PERMISSION_ROLES_ID = "permission_roles_id";

    public static final String TB_ORDER_ORDER_ID = "order_id";
    public static final String TB_ORDER_DATE = "order_date";
    public static final String TB_ORDER_STATUS = "status";
    public static final String TB_ORDER_INVOICE = "invoice";
    public static final String TB_ORDER_USERNAME= "username";

    public static final String TB_BUY_LIST_PRODUCT_ID = "product_id";
    public static final String TB_BUY_LIST_PRODUCT_NAME = "product_name";
    public static final String TB_BUY_LIST_PRODUCT_PRICE = "price";
    public static final String TB_BUY_LIST_PRODUCT_AMOUNT = "amount";

    public static final String TB_CART_USERNAME = "username";
    public static final String TB_CART_PRODUCT_ID = "productId";
    public static final String TB_CART_AMOUNT = "amount";


}