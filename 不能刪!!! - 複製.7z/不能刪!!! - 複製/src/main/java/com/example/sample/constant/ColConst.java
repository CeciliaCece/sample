package com.example.sample.constant;

public class ColConst {
    public static final String CURSOR = "o_cur";

    public static final String I_PRODUCT_ID = "i_product_id";
    public static final String I_PRODUCT_NAME = "i_product_name";
    public static final String I_DESCRIPTION = "i_description";
    public static final String I_PRICE = "i_price";
    public static final String I_STOCK = "i_stock";

    public static final String I_USERNAME = "i_username";
    public static final String I_USER_PASSWORD = "i_user_password";
    public static final String I_LAST_NAME = "i_last_name";
    public static final String I_FIRST_NAME = "i_first_name";
    public static final String I_PHONE = "i_phone";
    public static final String I_USER_ROLE = "i_user_role";

    public static final String I_PERMISSION_ID = "i_permission_id";
    public static final String I_PERMISSION_NAME = "i_permission_name";
    public static final String I_PERMISSION_CNAME = "i_permission_cname";
    public static final String I_PERMISSION_ROLES = "i_permission_roles";
    public static final String I_PERMISSION_ROLES_ID = "i_permission_roles_id";

    public static final String I_ORDER_ID = "i_order_id";
    public static final String I_ORDER_DATE = "i_order_date";
    public static final String I_STATUS = "i_status";
    public static final String I_INVOICE = "i_invoice";

    public static final String I_AMOUNT = "i_amount";

}