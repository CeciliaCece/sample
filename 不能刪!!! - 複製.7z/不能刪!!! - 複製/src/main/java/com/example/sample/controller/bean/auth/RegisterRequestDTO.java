package com.example.sample.controller.bean.auth;

import lombok.Data;

@Data
public class RegisterRequestDTO {
    private String username;
    private String userPassword;
    private String lastName;
    private String firstName;
    private String phone;
}
