package com.example.sample.service.mapper;

import com.example.sample.controller.bean.BuyListDTO;
import com.example.sample.controller.bean.order.GetOrderResponseDTO;
import com.example.sample.controller.bean.order.QueryOrderResponseDTO;
import com.example.sample.dao.bean.BuyListPO;
import com.example.sample.dao.bean.OrderPO;
import com.example.sample.service.bean.BuyListBO;
import com.example.sample.service.bean.OrderBO;
import lombok.Data;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.stream.Collectors;

@Data
public class OrderServiceMapper {


    private ModelMapper modelMapper;

    public OrderServiceMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public OrderBO toOrderBO(OrderPO orderPO) {
        return modelMapper.map(orderPO, OrderBO.class);
    }

    public List<OrderBO> toOrderBOList(List<OrderPO> orderPOs) {
        return orderPOs.stream().map(this::toOrderBO).collect(Collectors.toList());
    }

    public BuyListBO toBuyListDetails(BuyListPO buyListPO) {
        return modelMapper.map(buyListPO, BuyListBO.class);
    }

    public List<BuyListBO> toBuyListDetails(List<BuyListPO> buyListPOs) {
        return buyListPOs.stream().map(this::toBuyListDetails).collect(Collectors.toList());
    }

    public QueryOrderResponseDTO toQueryOrderResponseDTO(List<OrderBO> orderBOs) {
        List<QueryOrderResponseDTO.OrderDetails> orderDetails = orderBOs.stream()
                .map(orderBO -> {
                    QueryOrderResponseDTO.OrderDetails details = modelMapper.map(orderBO, QueryOrderResponseDTO.OrderDetails.class);
                    details.setBuylist(orderBO.getBuylist().stream()
                            .map(buyListDetails -> modelMapper.map(buyListDetails, BuyListDTO.class))
                            .collect(Collectors.toList()));
                    return details;
                })
                .collect(Collectors.toList());

        return new QueryOrderResponseDTO(orderDetails);
    }

    public GetOrderResponseDTO toGetOrderResponseDTO(List<OrderBO> orderBOs) {
        List<GetOrderResponseDTO.OrderDetails> orderDetails = orderBOs.stream()
                .map(orderBO -> {
                    GetOrderResponseDTO.OrderDetails details = modelMapper.map(orderBO, GetOrderResponseDTO.OrderDetails.class);
                    List<BuyListDTO> buyListDTOs = orderBO.getBuylist().stream()
                            .map(buyListDetails -> modelMapper.map(buyListDetails, BuyListDTO.class))
                            .collect(Collectors.toList());
                    details.setBuylist(buyListDTOs);
                    return details;
                })
                .collect(Collectors.toList());
        return new GetOrderResponseDTO(orderDetails);
    }
}
