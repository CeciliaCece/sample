package com.example.sample.dao.bean;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PermissionPO {
    private int permissionId;
    private String permissionName;
    private String permissionCname;
    private List<String> permissionRoles;
    private List<Integer> permissionRolesId;
}
