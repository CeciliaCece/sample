package com.example.sample.dao.mapper;

import com.example.sample.constant.DbConst;
import com.example.sample.dao.bean.BuyListPO;
import com.example.sample.utils.ResultSetUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class BuyListMapper implements RowMapper<BuyListPO> {
    @Override
    public BuyListPO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return BuyListPO.builder()
                .productId(ResultSetUtil.getIntSafe(rs, DbConst.TB_BUY_LIST_PRODUCT_ID))
                .productName(ResultSetUtil.getStringSafe(rs, DbConst.TB_BUY_LIST_PRODUCT_NAME))
                .price(ResultSetUtil.getBigDecimalSafe(rs, DbConst.TB_BUY_LIST_PRODUCT_PRICE))
                .amount(ResultSetUtil.getIntSafe(rs, DbConst.TB_BUY_LIST_PRODUCT_AMOUNT))
                .build();
    }
}
