package com.example.sample.controller.bean.product;

import lombok.Data;

@Data
public class DeleteProductRequestDTO {
    private int productId;
}
