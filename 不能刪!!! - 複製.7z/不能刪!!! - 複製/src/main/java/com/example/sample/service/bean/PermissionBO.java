package com.example.sample.service.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PermissionBO {
    private int permissionId;
    private String permissionName;
    private String permissionCname;
    private List<Integer> permissionRoles;
    private List<Integer> permissionRolesId;
}
