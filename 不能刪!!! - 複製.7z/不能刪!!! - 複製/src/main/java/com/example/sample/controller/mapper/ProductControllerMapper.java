package com.example.sample.controller.mapper;
import com.example.sample.controller.bean.product.AddProductRequestDTO;
import com.example.sample.controller.bean.product.DeleteProductRequestDTO;
import com.example.sample.controller.bean.product.GetProductRequestDTO;
import com.example.sample.controller.bean.product.UpdateProductRequestDTO;
import com.example.sample.service.bean.ProductBO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProductControllerMapper {

    @Autowired
    ModelMapper modelMapper;


    public ProductBO toAddProductRequestBO(AddProductRequestDTO addProductRequestDTO) {
        return modelMapper.map(addProductRequestDTO, ProductBO.class);
    }

    public ProductBO toUpdateProductRequestBO(UpdateProductRequestDTO updateProductRequestDTO) {
        return modelMapper.map(updateProductRequestDTO, ProductBO.class);
    }

    public ProductBO toDeleteProductRequestBO(DeleteProductRequestDTO deleteProductRequestDTO) {
        return modelMapper.map(deleteProductRequestDTO, ProductBO.class);
    }

    public ProductBO toGetProductRequestBO(GetProductRequestDTO getProductRequestDTO) {
        return modelMapper.map(getProductRequestDTO, ProductBO.class);
    }
}