package com.example.sample.dao.bean;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BankInfoPO {
    private String bankCode;
    private String bankName;
    private String branchCode;
    private String branchName;
}