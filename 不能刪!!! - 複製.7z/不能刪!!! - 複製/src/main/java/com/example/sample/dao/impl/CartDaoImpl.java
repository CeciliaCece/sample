package com.example.sample.dao.impl;

import com.example.sample.constant.ColConst;
import com.example.sample.constant.DbConst;
import com.example.sample.constant.ProcedureConst;
import com.example.sample.constant.ReturnCode;
import com.example.sample.dao.CartDao;
import com.example.sample.dao.bean.BuyListPO;
import com.example.sample.dao.mapper.BuyListMapper;
import com.example.sample.exception.SampleException;
import lombok.Data;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.sql.Types;
import java.util.List;
import java.util.Map;

@Data
public class CartDaoImpl implements CartDao {

    private JdbcTemplate jdbcTemplate;
    @Override
    public List<BuyListPO> getCart(String username) {

            MapSqlParameterSource in = new MapSqlParameterSource()
                    .addValue(ColConst.I_USERNAME, username);
            try {
                Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                        .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                        .withProcedureName(ProcedureConst.PC_G_CART)
                        .declareParameters(
                                new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR))
                        .returningResultSet(ColConst.CURSOR, new BuyListMapper())
                        .execute(in);
                List<BuyListPO> result = (List<BuyListPO>) resultMap.get(ColConst.CURSOR);

                if (!result.isEmpty()) {
                    return result;
                } else {
                    throw new SampleException(ReturnCode.DATA_NOT_FOUND);
                }
            } catch (Exception e) {
                throw new SampleException(ReturnCode.DB_ERROR, e);
            }
        }


    @Override
    public void addCart(String username, int productId, int amount) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_USERNAME, username)
                .addValue(ColConst.I_PRODUCT_ID, productId)
                .addValue(ColConst.I_AMOUNT, amount);

        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_C_CART)
                    .declareParameters(
                            new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_PRODUCT_ID, Types.INTEGER),
                            new SqlParameter(ColConst.I_AMOUNT, Types.INTEGER)
                    ).execute(in);

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }

    }

    @Override
    public void updateCart(String username, int productId, int amount) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_USERNAME, username)
                .addValue(ColConst.I_PRODUCT_ID, productId)
                .addValue(ColConst.I_AMOUNT, amount);

        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_U_CART)
                    .declareParameters(
                            new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_PRODUCT_ID, Types.INTEGER),
                            new SqlParameter(ColConst.I_AMOUNT, Types.INTEGER)
                    ).execute(in);

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }

    }

    @Override
    public void deleteCart(String username, int productId) {
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue(ColConst.I_USERNAME, username)
                .addValue(ColConst.I_PRODUCT_ID, productId);

        try {
            Map<String, Object> resultMap = new SimpleJdbcCall(this.getJdbcTemplate())
                    .withSchemaName(DbConst.SCHEMA_TRAVEL_TOGETHER)
                    .withProcedureName(ProcedureConst.PC_D_CART)
                    .declareParameters(
                            new SqlParameter(ColConst.I_USERNAME, Types.VARCHAR),
                            new SqlParameter(ColConst.I_PRODUCT_ID, Types.INTEGER)
                    ).execute(in);

        } catch (Exception e) {
            throw new SampleException(ReturnCode.DB_ERROR, e);
        }

    }
}
