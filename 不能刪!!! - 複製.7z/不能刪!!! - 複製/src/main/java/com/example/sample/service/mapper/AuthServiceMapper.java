package com.example.sample.service.mapper;

import com.example.sample.controller.bean.auth.LoginResponseDTO;
import com.example.sample.dao.bean.AuthPO;
import com.example.sample.service.bean.AuthBO;
import lombok.Data;
import org.modelmapper.ModelMapper;

@Data
public class AuthServiceMapper {
    private ModelMapper modelMapper;

    public LoginResponseDTO toLoginResponseDTO(AuthBO authBO) {
        return modelMapper.map(authBO, LoginResponseDTO.class);
    }

    public AuthBO toLoginBO(AuthPO authPO) {
        return modelMapper.map(authPO, AuthBO.class);
    }
}
