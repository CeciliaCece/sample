package com.example.sample.service.impl;

import com.example.sample.controller.bean.permission.QueryPermissionResponseDTO;
import com.example.sample.dao.PermissionDao;
import com.example.sample.dao.bean.PermissionPO;
import com.example.sample.service.PermissionService;
import com.example.sample.service.bean.PermissionBO;
import com.example.sample.service.mapper.PermissionServiceMapper;
import lombok.Setter;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Setter
public class PermissionServiceImpl implements PermissionService {

    private PermissionDao permissionDao;

    private PermissionServiceMapper mapper;

    @Override
    @Transactional
    public PermissionPO getRolesByPermissionName(String permissionName) {
        return permissionDao.getRolesByPermissionName(permissionName);
    }

    @Override
    @Transactional
    public QueryPermissionResponseDTO queryPermissions() {
        List<PermissionPO> permissionPOs = permissionDao.queryPermissions();
        return mapper.toQueryPermissionResponseDTO(mapper.toPermissionBOList(permissionPOs));
    }

    @Override
    @Transactional
    public void updatePermission(PermissionBO permissionBO) {
        permissionDao.updatePermission(permissionBO.getPermissionId(),permissionBO.getPermissionRolesId());
    }


}
