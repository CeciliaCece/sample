package com.example.sample.dao;

import com.example.sample.dao.bean.BuyListPO;

import java.util.List;

public interface CartDao {
    List<BuyListPO> getCart(String username);
    void addCart(String username ,int productId, int amount);
    void updateCart(String username ,int productId, int amount);
    void deleteCart(String username ,int productId);
}
