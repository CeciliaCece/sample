package com.example.sample.controller;

import com.example.sample.constant.ReturnCode;
import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.bean.base.RestRequest;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.controller.bean.permission.QueryPermissionResponseDTO;
import com.example.sample.controller.bean.permission.UpdatePermissionRequestDTO;
import com.example.sample.controller.mapper.PermissionControllerMapper;
import com.example.sample.service.PermissionService;
import com.example.sample.utils.ResponseFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("permission/v1")
public class PermissionController {

    @Autowired
    private PermissionService permissionService;
    @Autowired
    private PermissionControllerMapper mapper;


    @PostMapping(value = "/queryPermissions")
    public RestResponse<QueryPermissionResponseDTO> queryPermissions() {
        QueryPermissionResponseDTO queryPermissionResponseDTO = permissionService.queryPermissions();
        return ResponseFactory.createSuccessResponse(queryPermissionResponseDTO);
    }

    @PostMapping(value = "/updatePermission")
    public RestResponse<ResultDTO> updatePermission(@Valid @RequestBody RestRequest<UpdatePermissionRequestDTO> request) {
        UpdatePermissionRequestDTO updatePermissionRequestDTO = request.getBody();
        permissionService.updatePermission(mapper.toUpdatePermissionRequestBO(updatePermissionRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Permission updated successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }

}