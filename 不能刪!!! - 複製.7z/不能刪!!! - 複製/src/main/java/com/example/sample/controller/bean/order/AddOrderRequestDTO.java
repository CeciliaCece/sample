package com.example.sample.controller.bean.order;

import lombok.Data;

@Data
public class AddOrderRequestDTO {
    private String username;
    private String orderDate;
    private String invoice;

}
