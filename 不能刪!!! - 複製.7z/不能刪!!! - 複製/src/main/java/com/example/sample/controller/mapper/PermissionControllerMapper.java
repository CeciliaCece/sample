package com.example.sample.controller.mapper;

import com.example.sample.controller.bean.permission.UpdatePermissionRequestDTO;
import com.example.sample.service.bean.PermissionBO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class PermissionControllerMapper {
        @Autowired
        ModelMapper modelMapper;

        public PermissionBO toUpdatePermissionRequestBO(UpdatePermissionRequestDTO updatePermissionRequestDTO) {
            return modelMapper.map(updatePermissionRequestDTO, PermissionBO.class);
        }

    }

