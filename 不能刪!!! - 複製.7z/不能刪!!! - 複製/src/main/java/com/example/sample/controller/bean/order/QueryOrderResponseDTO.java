package com.example.sample.controller.bean.order;

import com.example.sample.controller.bean.BuyListDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryOrderResponseDTO {
    private List<OrderDetails> orderDetails;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrderDetails {
        private int orderId;
        private String username;
        private String orderDate;
        private int status;
        private String invoice;
        private List<BuyListDTO> buylist;
    }

}
