package com.example.sample.controller.bean.base;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestResponse<Body> implements Serializable {
    private static final long serialVersionUID = -6505652263359301794L;
    private ResponseHeader header;

    private Body body;

    @Data
    public static class ResponseHeader implements Serializable {

        private static final long serialVersionUID = -8475294974269111596L;

        private String resultCode;
        private String resultDescription;
    }
}