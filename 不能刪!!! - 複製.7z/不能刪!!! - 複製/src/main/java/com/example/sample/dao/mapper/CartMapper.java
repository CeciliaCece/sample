package com.example.sample.dao.mapper;

import com.example.sample.constant.DbConst;
import com.example.sample.dao.bean.CartPO;
import com.example.sample.utils.ResultSetUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CartMapper implements RowMapper<CartPO> {
    @Override
    public CartPO mapRow(ResultSet rs, int i) throws SQLException {
        return CartPO.builder()
                .username(ResultSetUtil.getStringSafe(rs, DbConst.TB_CART_USERNAME))
                .productId(ResultSetUtil.getIntSafe(rs, DbConst.TB_CART_PRODUCT_ID))
                .amount(ResultSetUtil.getIntSafe(rs, DbConst.TB_CART_AMOUNT))
                .build();
    }
}
