package com.example.sample.constant;

public class SecurityConstant {
    public static final String JWT_KEY = "zUxjq8TbUmMiZ1z58fEVb1xFz5aGkWqs8yYHBFT0e0YqkK8Y8vMZMT1T6vxkW4g5HzI6sH9dZ+7n9g+kGn9rDw==";
    public static final String AUTH_HEADER = "Authorization";
    public static final String JWT_BEARER ="Bearer ";
    public static final String ROLE_UNKNOWN ="ROLE_UNKNOWN";

}
