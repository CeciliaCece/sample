package com.example.sample.controller.bean.permission;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryPermissionResponseDTO {
    private List<PermissionDetails> permissionsDetails;

    @Data
    public static class PermissionDetails {
        private int permissionId;
        private String permissionName;
        private String permissionCname;
        private List<Integer> permissionRolesId;
    }
}
