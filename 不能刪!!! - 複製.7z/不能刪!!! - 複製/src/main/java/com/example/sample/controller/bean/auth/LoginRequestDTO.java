package com.example.sample.controller.bean.auth;

import lombok.Data;

@Data
public class LoginRequestDTO {
    private String username;
    private String userPassword;
}
