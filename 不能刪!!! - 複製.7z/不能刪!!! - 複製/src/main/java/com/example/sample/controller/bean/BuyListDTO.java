package com.example.sample.controller.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BuyListDTO {
    private int productId;
    private String productName;
    private BigDecimal price;
    private int amount;
}
