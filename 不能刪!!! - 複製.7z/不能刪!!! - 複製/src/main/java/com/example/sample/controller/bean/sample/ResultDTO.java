package com.example.sample.controller.bean.sample;

import lombok.Data;

@Data
public class ResultDTO {
    private String resultCode;
    private String resultDescription;
}