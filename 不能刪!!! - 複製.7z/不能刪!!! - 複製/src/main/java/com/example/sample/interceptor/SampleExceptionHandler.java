package com.example.sample.interceptor;

import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.exception.SampleException;
import com.example.sample.utils.ResponseFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class SampleExceptionHandler {

    private static final Logger LOG = LogManager.getLogger(ExceptionHandler.class.getName());

    @ExceptionHandler(value = SampleException.class)
    @ResponseBody
    public RestResponse<ResultDTO> errorHandler(SampleException e) {
        LOG.error("handleSampleException",e);
        return ResponseFactory.createErrorResponse(e.getReturnCode().getCode(),e.getReturnCode().getValue(),e.getCause());
    }
}