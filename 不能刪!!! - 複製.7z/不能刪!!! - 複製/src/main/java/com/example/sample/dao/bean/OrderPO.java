package com.example.sample.dao.bean;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderPO {
    private int orderId;
    private String username;
    private String orderDate;
    private int status;
    private String invoice;

}
