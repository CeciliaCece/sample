package com.example.sample.service.impl;

import com.example.sample.controller.bean.sample.BankInfoDTO;
import com.example.sample.dao.SampleDao;
import com.example.sample.dao.bean.BankInfoPO;
import com.example.sample.service.SampleService;
import com.example.sample.service.bean.BankInfoBO;
import lombok.Setter;
import org.springframework.transaction.annotation.Transactional;


@Setter
public class SampleServiceImpl implements SampleService {

    SampleDao sampleDao;

    @Override
    @Transactional
    public BankInfoDTO getBankInfo(BankInfoBO bo) {

        BankInfoPO bankInfoPO = sampleDao.getBankInfo(bo.getBankCode(), bo.getBranchCode());

        return BankInfoBO.createBy(bankInfoPO).getBankInfoDTO();
    }
}