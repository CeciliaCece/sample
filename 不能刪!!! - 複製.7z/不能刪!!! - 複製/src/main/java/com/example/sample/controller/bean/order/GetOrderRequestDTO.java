package com.example.sample.controller.bean.order;

import lombok.Data;

@Data
public class GetOrderRequestDTO {
    private String username;
}
