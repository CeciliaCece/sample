package com.example.sample.controller;

import com.example.sample.constant.ReturnCode;
import com.example.sample.controller.bean.base.RestRequest;
import com.example.sample.controller.bean.base.RestResponse;
import com.example.sample.controller.bean.order.*;
import com.example.sample.controller.bean.sample.ResultDTO;
import com.example.sample.controller.mapper.OrderControllerMapper;
import com.example.sample.service.OrderService;
import com.example.sample.utils.ResponseFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("order/v1")
public class OrderController {

    @Autowired
    private OrderService orderService;
    @Autowired
    private OrderControllerMapper mapper;

    @PostMapping(value = "/queryOrders")
    public RestResponse<QueryOrderResponseDTO> queryOrders() {
        QueryOrderResponseDTO queryOrderResponseDTOs = orderService.queryOrders();
        return ResponseFactory.createSuccessResponse(queryOrderResponseDTOs);
    }

    @PostMapping(value = "/getOrders")
    public RestResponse<GetOrderResponseDTO> getOrders(@Valid @RequestBody RestRequest<GetOrderRequestDTO> request) {
        GetOrderRequestDTO getOrderRequestDTO = request.getBody();
        GetOrderResponseDTO getOrderResponseDTOs = orderService.getOrders(mapper.toGetOrderRequestBO(getOrderRequestDTO));
        return ResponseFactory.createSuccessResponse(getOrderResponseDTOs);
    }

    @PostMapping(value = "/addOrder")
    public RestResponse<ResultDTO> addOrder(@Valid @RequestBody RestRequest<AddOrderRequestDTO> request) {
        AddOrderRequestDTO addOrderRequestDTO = request.getBody();
        orderService.addOrder(mapper.toAddOrderRequestBO(addOrderRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Order added successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }

    @PostMapping(value = "/updateOrder")
    public RestResponse<ResultDTO> updateOrder(@Valid @RequestBody RestRequest<UpdateOrderRequestDTO> request) {
        UpdateOrderRequestDTO updateOrderRequestDTO = request.getBody();
        orderService.updateOrder(mapper.toUpdateOrderRequestBO(updateOrderRequestDTO));

        ResultDTO dto = new ResultDTO();
        dto.setResultCode(ReturnCode.SUCCESS.getCode());
        dto.setResultDescription("Order updated successfully");
        return ResponseFactory.createSuccessResponse(dto);
    }

}
