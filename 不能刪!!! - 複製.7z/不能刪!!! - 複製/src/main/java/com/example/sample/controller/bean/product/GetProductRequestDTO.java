package com.example.sample.controller.bean.product;

import lombok.Data;

@Data
public class GetProductRequestDTO {
    private int productId;
}
