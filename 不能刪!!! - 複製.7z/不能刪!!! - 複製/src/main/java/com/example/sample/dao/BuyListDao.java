package com.example.sample.dao;

import com.example.sample.dao.bean.BuyListPO;

import java.util.List;

public interface BuyListDao {

    List<BuyListPO> getBuyLists(int OrderId);

}
