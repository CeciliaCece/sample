package com.example.sample.constant;

public class AopConst {
    private static final String POINTCUT_DEFINITION_PATH =
            "com.esb.simple.aop.PointcutDefinition.";
    public static final String POINTCUT_SIMPLE_LOG_LAYER =
            POINTCUT_DEFINITION_PATH + "simpleLogLayer()";
    public static final String POINTCUT_AUTH_SECURED_LAYER =
            POINTCUT_DEFINITION_PATH + "authSecuredLayer()";
}
