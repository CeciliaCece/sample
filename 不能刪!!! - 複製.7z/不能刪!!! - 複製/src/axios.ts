import axios from "axios";
import store from "./store";

const axiosInstance = axios.create({
  baseURL: "http://localhost:15593/traveltogether",
});

axiosInstance.interceptors.request.use((config) => {
  const token = store.getters.token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default axiosInstance;
