import { createStore } from "vuex";
import createPersistedState from "vuex-persistedstate";

interface Product {
  productId: number;
  productName: string;
  description: string;
  price: number;
  stock: number;
  amount: number;
}

const store = createStore({
  state: {
    token: "",
    username: "",
    role: "",
    buylist: [] as Product[],
    isCartVisible: false,
  },
  mutations: {
    setToken(state, token) {
      state.token = token;
    },
    setUsername(state, username) {
      state.username = username;
    },
    setRole(state, role) {
      state.role = role;
    },
    setCart(state, buylist) {
      state.buylist = buylist;
    },
    clearAuth(state) {
      state.token = "";
      state.username = "";
      state.role = "";
      state.buylist = [];
    },
    addToCart(state, product) {
      const existingProduct = state.buylist.find(
        (item) => item.productId === product.productId
      );
      if (existingProduct) {
        existingProduct.amount += product.amount;
      } else {
        state.buylist.push(product);
      }
    },
  },
  actions: {
    login({ commit }, { token, username, role }) {
      commit("setToken", token);
      commit("setUsername", username);
      commit("setRole", role);
    },
    logout({ commit }) {
      commit("clearAuth");
    },
    setCart({ commit }, buylist) {
      commit("setBuylist", buylist);
    },
    addToCart({ commit }, product) {
      commit("addToCart", product);
    },
  },
  getters: {
    isAuthenticated: (state) => !!state.token,
    userRole: (state) => state.role,
    username: (state) => state.username,
    token: (state) => state.token,
    buylist: (state) => state.buylist,
    cartItemCount: (state) => {
      return state.buylist.reduce((total, item) => total + item.amount, 0);
    },
  },
  plugins: [createPersistedState()],
});

export default store;
