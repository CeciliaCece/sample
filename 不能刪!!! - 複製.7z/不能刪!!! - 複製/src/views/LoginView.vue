<script setup lang="ts">
import { defineComponent, ref } from "vue";
import { useStore } from "vuex";
import axiosInstance from "../axios";
import { useRouter } from "vue-router";

const username = ref("");
const password = ref("");
const message = ref("");
const store = useStore();
const router = useRouter();

const login = async () => {
  try {
    const token = btoa(`${username.value}:${password.value}`);
    const response = await axiosInstance.post(
      "/auth/v1/login",
      {},
      {
        headers: {
          Authorization: `Basic ${token}`,
        },
      }
    );

    const { token: jwtToken, role } = response.data;
    store.dispatch("login", {
      token: jwtToken,
      role,
      username: username.value,
    });

    const buylist = store.getters.buylist;
    if (buylist.length > 0) {
      for (const item of buylist) {
        await axiosInstance.post("/cart/v1/addCart", {
          body: {
            productId: item.productId,
            username: username.value,
            amount: item.amount,
          },
        });
      }
      store.dispatch("setCart",[]);
    }

    const cartResponse = await axiosInstance.post("/cart/v1/getCart", {
      body: {
        username: username.value,
      },
    });
    if (cartResponse.data.header.resultCode === "0000") {
      store.dispatch("setCart", cartResponse.data.body.buylist);
    }

    alert("登入成功");
    router.push("/");
    message.value = "";
  } catch (error) {
    console.error("Login failed:", error);
    message.value = "Login failed, please check your credentials.";
  }
};

const goToRegister = () => {
  router.push("/register");
};
</script>

<template>
  <div class="container pt-5">
    <div class="row justify-content-center">
      <div class="col-md-5">
        <h2 class="mb-3 text-center">Sign In</h2>
        <form @submit.prevent="login">
          <div class="mb-3">
            <label htmlFor="username" class="form-label w-100">帳號</label>
            <input
              id="username"
              class="form-control"
              name="username"
              type="text"
              v-model="username"
              placeholder="Username"
            />
          </div>
          <div class="mb-3">
            <label htmlFor="password" class="form-label w-100">密碼</label>
            <input
              type="password"
              class="form-control"
              name="password"
              id="password"
              v-model="password"
              placeholder="Password"
            />
          </div>
          <div v-if="message" class="alert alert-danger mb-3 mt-5" role="alert">
            {{ message }}
          </div>
          <div class="pt-3 text-center">
            <button type="submit" class="btn btn-primary px-5">登入</button>
          </div>
        </form>
        <div class="text-center pt-3">
          <a @click="goToRegister">註冊帳號</a>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.container {
  padding-top: 20px;
}
</style>
