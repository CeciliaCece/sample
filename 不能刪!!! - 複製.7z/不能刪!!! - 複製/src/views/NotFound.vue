<template>
  <div>
    <h1>404 - Not Found</h1>
  </div>
</template>

<script lang="ts">
export default {
  name: "NotFound",
};
</script>
