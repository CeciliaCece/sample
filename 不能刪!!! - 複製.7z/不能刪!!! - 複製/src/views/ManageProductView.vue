<template>
  <div>
    <router-link :to="{ name: 'addProduct' }">
      <button type="button" class="btn btn-primary d-flex align-items-center">
        <BIconPlusCircle class="me-2" />
        <span>新增商品</span>
      </button>
    </router-link>
    <div class="product-list">
      <div
        v-for="(product, index) in products"
        :key="index"
        class="product-item bg-white w-75 m-2 rounded text-primary p-3"
      >
        <ul class="m-0 p-0 d-flex justify-content-between">
          <li class="ms-4">{{ product.productId }}</li>
          <li>{{ product.productName }}</li>
          <li>{{ product.description }}</li>
          <li class="d-flex justify-content-between">
            <p>NT$</p>
            <p>{{ product.price }}</p>
          </li>
          <li>{{ product.stock }}</li>
          <li>
            <router-link
              :to="{ name: 'editProduct', params: { id: product.productId } }"
            >
              <button type="button" class="btn btn-outline-secondary">
                修改
              </button>
            </router-link>
          </li>
          <li>
            <button
              type="button"
              class="btn btn-outline-danger"
              @click="deleteProduct(product.productId)"
            >
              刪除
            </button>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from "vue";
import { BIconPlusCircle } from "bootstrap-icons-vue";
import axiosInstance from "@/axios";

interface Product {
  productId: number;
  productName: string;
  description: string;
  price: number;
  stock: number;
}

const products = ref<Product[]>([]);

const fetchProducts = async () => {
  try {
    const response = await axiosInstance.post("/product/v1/queryProducts", {});
    if (response.data.header.resultCode === "0000") {
      products.value = response.data.body.productDetails;
    } else {
      console.error(
        "Failed to fetch products:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error fetching products:", error);
  }
};

const deleteProduct = async (productId: number) => {
  try {
    const response = await axiosInstance.post("/product/v1/deleteProduct", {
      body: {
        productId: productId,
      },
    });
    if (response.data.header.resultCode === "0000") {
      alert("商品已刪除");
      // 刷新產品列表
      fetchProducts();
    } else {
      console.error(
        "Failed to delete product:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error deleting product:", error);
  }
};

onMounted(fetchProducts);
</script>

<style lang="scss" scoped>
.product-list {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.product-item ul {
  list-style: none;
  display: flex;
  justify-content: space-between;
  padding: 8px 24px;
  width: 100%;
}

.product-item li {
  flex: 1;
  text-align: center;
}

.product-item li p {
  margin: 0;
}
</style>
