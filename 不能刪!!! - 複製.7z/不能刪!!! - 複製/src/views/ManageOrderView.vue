<script setup lang="ts">
import AdminCollapseOrder from "@/components/AdminCollapseOrder.vue";
import { ref, onMounted } from "vue";
import axiosInstance from "@/axios";
import { useStore } from "vuex";

interface BuyList {
  productId: number;
  productName: string;
  price: number;
  amount: number;
}

interface Order {
  orderId: number;
  username: string;
  orderDate: string;
  status: number;
  invoice: string;
  buylist: BuyList[];
}

const orders = ref<Order[]>([]);

const store = useStore();

async function fetchOrders() {
  try {
    const response = await axiosInstance.post("/order/v1/queryOrders", {
      // If any specific request parameters are needed, add them here.
    });
    if (response.data.header.resultCode === "0000") {
      orders.value = response.data.body.orderDetails;
    } else {
      console.error(
        "Failed to fetch orders:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error fetching orders:", error);
  }
}

onMounted(fetchOrders);
</script>

<template>
  <h1>訂單管理</h1>
  <div class="container d-flex flex-wrap justify-content-center bg-secondary">
    <div class="bg-secondary m-2 text-primary">
      <ul class="m-0 p-0 d-flex justify-content-between">
        <li class="ms-4">訂單編號</li>
        <li>訂購日期</li>
        <li>訂單狀態</li>
        <li>訂單總額</li>
        <li>訂單發票</li>
        <li></li>
      </ul>
    </div>
    <AdminCollapseOrder
      v-for="(order, index) in orders"
      :key="index"
      :id="order.orderId"
      :date="order.orderDate"
      :status="order.status"
      :invoice="order.invoice"
      :buylist="order.buylist"
    />
  </div>
</template>

<style lang="scss" scoped>
ul {
  text-align: center;
}

li {
  list-style: none;
  padding: 8px 24px;
  width: 144px;
  min-width: 144px;
  margin: 0px 10px;
}
</style>
