<script setup lang="ts">
import { ref, onMounted } from "vue";
import ProductCard from "@/components/HomeProductCard.vue";
import axiosInstance from "../axios";

interface Product {
  productId: number;
  productName: string;
  description: string;
  price: number;
  stock: number;
}

const products = ref<Product[]>([]);

const fetchProducts = async () => {
  try {
    const response = await axiosInstance.post("/product/v1/queryProducts");
    if (response.data.header.resultCode === "0000") {
      products.value = response.data.body.productDetails;
    } else {
      console.error(
        "Failed to fetch products:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error fetching products:", error);
  }
};

onMounted(fetchProducts);
</script>

<template>
  <img class="w-100 d-block" src="../assets/title_image.jpg" alt="廣告" />
  <div class="container-xl">
    <div class="d-flex flex-wrap pt-5 px-2">
      <ProductCard
        v-for="product in products"
        :key="product.productId"
        :productId="product.productId"
        :productName="product.productName"
        :description="product.description"
        :price="product.price"
        :stock="product.stock"
      />
    </div>
  </div>
</template>
