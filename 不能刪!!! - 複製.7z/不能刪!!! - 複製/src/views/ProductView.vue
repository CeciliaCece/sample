<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { useRoute } from "vue-router";
import { useStore } from "vuex";
import axiosInstance from "../axios";
import { BIconClock, BIconPercent } from "bootstrap-icons-vue";

interface Product {
  productName: string;
  description: string;
  price: number;
  stock: number;
}

const route = useRoute();
const store = useStore();
const productId = route.params.id;

const product = ref<Product | null>(null);
const selectedAmount = ref<number>(1);

const fetchProduct = async () => {
  try {
    const response = await axiosInstance.post("/product/v1/getProduct", {
      body: {
        productId: productId,
      },
    });
    if (response.data.header.resultCode === "0000") {
      product.value = response.data.body;
    } else {
      console.error(
        "Failed to fetch product:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error fetching product:", error);
  }
};

onMounted(fetchProduct);

const subtotal = computed(() => {
  return product.value ? product.value.price * selectedAmount.value : 0;
});

const addToCart = async () => {
  try {
    const username = store.getters.username;
    await axiosInstance.post("/cart/v1/addCart", {
      body: {
        productId: productId,
        username: username,
        amount: selectedAmount.value,
      },
    });
    alert("商品已加入購物車");
  } catch (error) {
    console.error("加入購物車失敗", error);
    alert("加入購物車失敗");
  }
};
</script>

<template>
  <div class="container">
    <div class="mt-5 row">
      <div class="col-7 d-flex align-items-center">
        <img class="img-fluid" src="../assets/card_image.jpg" alt="商品圖片" />
      </div>
      <div class="col-5">
        <div v-if="product">
          <h2>{{ product.productName }}</h2>
          <p class="text-info">{{ product.description }}</p>
        </div>
        <form class="border border-secondary p-4" @submit.prevent="addToCart">
          <p class="fs-3 fw-bold" v-if="product">NT$ {{ product.price }}</p>
          <div class="mb-3">
            <label for="amount" class="form-label">人數</label>
            <select
              v-model="selectedAmount"
              class="form-control"
              id="amount"
              aria-describedby="輸入人數"
              :disabled="product?.stock === 0"
            >
              <option v-if="product?.stock === 0" :value="0">0</option>
              <option
                v-else
                v-for="n in product?.stock || 0"
                :key="n"
                :value="n"
              >
                {{ n }}
              </option>
            </select>
          </div>
          <div class="text-info">
            <div class="d-flex align-content-center">
              <BIconClock class="mt-1" />
              <p class="ps-2">24小時內確認訂單</p>
            </div>
            <div class="d-flex">
              <BIconPercent class="mt-1" />
              <p class="ps-2">價格保證最低</p>
            </div>
          </div>
          <div class="d-flex justify-content-end align-items-center mb-2">
            <p class="me-3 mb-0">小計</p>
            <p class="fw-bold mb-0">NT$ {{ subtotal }}</p>
          </div>
          <div class="d-flex justify-content-end align-items-center">
            <button
              type="submit"
              class="btn btn-secondary"
              :disabled="product?.stock === 0"
            >
              {{ product?.stock === 0 ? "完售" : "加入購物車" }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped></style>
