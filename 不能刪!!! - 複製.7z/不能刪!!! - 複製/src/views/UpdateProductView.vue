<script setup lang="ts">
import { ref, computed, watch, onMounted } from "vue";
import { BIconImage } from "bootstrap-icons-vue";
import { useRoute, useRouter } from "vue-router";
import axiosInstance from "@/axios";

const route = useRoute();
const router = useRouter();

const isEdit = computed(() => route.params.id != null);

const formData = ref({
  productName: "",
  description: "",
  price: 0,
  stock: 0,
  image: null,
});

const fetchProduct = async (id: number) => {
  try {
    const response = await axiosInstance.post("/product/v1/getProduct", {
      body: { productId: id },
    });
    if (response.data.header.resultCode === "0000") {
      const product = response.data.body;
      formData.value = {
        productName: product.productName,
        description: product.description,
        price: product.price,
        stock: product.stock,
        image: null, // 默認為 null，因為不處理現有圖片
      };
    } else {
      console.error(
        "Failed to fetch product:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error fetching product:", error);
  }
};

watch(
  () => route.params.id,
  (newId) => {
    if (newId) {
      fetchProduct(Number(newId));
    }
  }
);

onMounted(() => {
  if (route.params.id) {
    fetchProduct(Number(route.params.id));
  }
});

const submitForm = async () => {
  const endpoint = isEdit.value
    ? "/product/v1/updateProduct"
    : "/product/v1/addProduct";
  const requestBody = isEdit.value
    ? {
        body: {
          productId: Number(route.params.id),
          productName: formData.value.productName,
          description: formData.value.description,
          price: formData.value.price,
          stock: formData.value.stock,
        },
      }
    : {
        body: {
          productName: formData.value.productName,
          description: formData.value.description,
          price: formData.value.price,
          stock: formData.value.stock,
        },
      };

  try {
    const response = await axiosInstance.post(endpoint, requestBody);
    if (response.data.header.resultCode === "0000") {
      alert(isEdit.value ? "商品已更新" : "商品已新增");
      if (!isEdit.value) {
        formData.value = {
          productName: "",
          description: "",
          price: 0,
          stock: 0,
          image: null,
        };
      }
    } else {
      console.error(
        "Failed to submit form:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error submitting form:", error);
  }
};
</script>

<template>
  <div class="container pt-5">
    <h2 class="fw-bold">{{ isEdit ? "修改商品" : "新增商品" }}</h2>
    <div class="mt-5 row">
      <div class="col d-flex align-items-center">
        <BIconImage class="text-info" />
      </div>
      <div class="col">
        <form @submit.prevent="submitForm">
          <div class="mb-3">
            <label for="productName" class="form-label">商品名稱</label>
            <input
              type="text"
              class="form-control"
              id="productName"
              v-model="formData.productName"
            />
          </div>
          <div class="mb-3">
            <label for="productDescript" class="form-label">商品描述</label>
            <textarea
              class="form-control"
              id="productDescript"
              rows="3"
              v-model="formData.description"
            ></textarea>
          </div>
          <div class="row">
            <div class="mb-3 col">
              <label for="productPrice" class="form-label">價格</label>
              <input
                type="number"
                class="form-control"
                id="productPrice"
                v-model="formData.price"
              />
            </div>
            <div class="mb-3 col">
              <label for="peopleRange" class="form-label">庫存</label>
              <input
                type="number"
                class="form-control"
                id="peopleRange"
                v-model="formData.stock"
              />
            </div>
          </div>
          <div class="mb-3">
            <label for="producPic" class="form-label">上傳圖片</label>
            <input class="form-control" type="file" id="producPic" />
          </div>
          <div class="d-flex justify-content-end align-items-center">
            <button type="submit" class="btn btn-secondary">
              {{ isEdit ? "確定修改" : "確定新增" }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped></style>
