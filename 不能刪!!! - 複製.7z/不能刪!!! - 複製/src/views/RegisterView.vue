<template>
  <div class="container pt-5">
    <div class="row justify-content-center">
      <div class="col-md-5">
        <h2 class="mb-3 text-center">Register</h2>
        <form @submit.prevent="register">
          <div class="mb-3">
            <label htmlFor="username" class="form-label w-100"
              >帳號<input
                id="username"
                class="form-control"
                name="username"
                type="text"
                v-model="username"
            /></label>
          </div>
          <div class="mb-3">
            <label htmlFor="password" class="form-label w-100"
              >密碼<input
                type="password"
                class="form-control"
                name="password"
                id="password"
                v-model="password"
            /></label>
          </div>
          <div class="mb-3">
            <label htmlFor="password2" class="form-label w-100"
              >再次輸入密碼<input
                type="password"
                class="form-control"
                name="password2"
                id="password2"
                v-model="password2"
            /></label>
          </div>
          <div class="mb-3 d-flex justify-content-between">
            <label htmlFor="lastname" class="form-label w-50 pe-2"
              >姓<input
                type="text"
                class="form-control"
                name="lastname"
                id="lastname"
                v-model="lastName"
            /></label>

            <label htmlFor="firstname" class="form-label w-50 ps-2"
              >名<input
                type="text"
                class="form-control"
                name="firstname"
                id="firstname"
                v-model="firstName"
            /></label>
          </div>
          <div class="mb-3">
            <label htmlFor="phone" class="form-label w-100"
              >電話<input
                type="number"
                class="form-control"
                name="phone"
                id="phone"
                v-model="phone"
            /></label>
          </div>
          <div v-if="message" class="alert alert-danger mb-3 mt-5" role="alert">
            {{ message }}
          </div>
          <div class="pt-3 text-center">
            <button type="submit" class="btn btn-primary px-4">註冊帳號</button>
          </div>
        </form>
        <div class="text-center pt-3">
          <a @click="goToLogin">登入</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { useRouter } from "vue-router";
import axiosInstance from "../axios";

const router = useRouter();

const username = ref("");
const password = ref("");
const password2 = ref("");
const lastName = ref("");
const firstName = ref("");
const phone = ref("");
const message = ref("");

const goToLogin = () => {
  router.push("/login");
};

const register = async () => {
  if (password.value !== password2.value) {
    message.value = "Passwords do not match.";
    return;
  }

  try {
    const response = await axiosInstance.post("/auth/v1/register", {
      body: {
        username: username.value,
        userPassword: password.value,
        lastName: lastName.value,
        firstName: firstName.value,
        phone: phone.value,
      },
    });

    if (response.data.body.resultCode === "0000") {
      alert("註冊成功");
      router.push("/login");
    } else {
      message.value =
        response.data.body.resultDescription ||
        "Registration failed, please try again.";
    }
  } catch (error) {
    console.error("Registration failed:", error);
    message.value = "Registration failed, please try again.";
  }
};
</script>
