<script setup lang="ts">
import { ref } from "vue";
import { BIconArrowBarRight } from "bootstrap-icons-vue";

const isClose = ref(false);
const toggleSideMenu = () => {
  isClose.value = !isClose.value;
};
</script>

<template>
  <div :class="['d-flex h-100', { 'sidebar-toggle': isClose }]">
    <aside
      class="sidebar border-end d-flex flex-column overflow-auto h-100 justify-content-between"
    >
      <ul class="list-group list-group-flush admin-sidebar-link">
        <router-link to="/admin/manageOrder" class="list-group-item py-3">
          訂單管理
        </router-link>
        <router-link to="/admin/manageProduct" class="list-group-item py-3">
          商品管理
        </router-link>
      </ul>
    </aside>
    <main class="main w-100 px-5 position-relative">
      <div class="position-absolute start-0 bg-primary-subtle rounded-end-4">
        <a @click="toggleSideMenu()">
          <div class="px-2 py-3 e">
            <BIconArrowBarRight />
          </div>
        </a>
      </div>
      <router-view></router-view>
    </main>
  </div>
</template>

<style lang="scss" scoped>
$sidebar-width: 200px;

.sidebar {
  height: calc(100vh - 60px);
  width: $sidebar-width;
  margin-left: -$sidebar-width;
  transition: margin-left 0.25s;
  background-color: #f0e3aa;
}

.main {
  width: 100%;
}

.sidebar-toggle {
  .sidebar {
    margin-left: 0;
  }

  .main {
    width: calc(100vw - #{$sidebar-width});
  }
}

@media only screen and (max-width: 992px) {
  .sidebar {
    width: $sidebar-width;
    margin-left: 0;
  }

  .main {
    width: calc(100vw - #{$sidebar-width});
  }

  .sidebar-toggle {
    .sidebar {
      margin-left: -$sidebar-width;
    }

    .main {
      width: 100%;
    }
  }
}
</style>
