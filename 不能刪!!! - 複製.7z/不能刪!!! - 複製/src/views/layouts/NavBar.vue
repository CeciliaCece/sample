<template>
  <nav class="navbar h-60px fixed-top bg-primary px-4">
    <ul class="nav d-flex align-items-center h-100">
      <li class="nav-item h-100 mt-m10px">
        <router-link to="/" class="nav-link text-light h-100 d-flex">
          <img src="../../assets/logo.png" alt="Logo" class="h-100" />
          <p class="text-bold fs-3 ms-3">Travel Together</p>
        </router-link>
      </li>
      <li
        class="nav-item"
        v-if="
          isAuthenticated &&
          (userRole === 'ROLE_ADMIN' || userRole === 'ROLE_CUSTOMER')
        "
      >
        <router-link to="/order" class="nav-link text-light"
          >訂單管理</router-link
        >
      </li>
      <li
        class="nav-item"
        v-if="
          isAuthenticated &&
          (userRole === 'ROLE_ADMIN' || userRole === 'ROLE_MANAGER')
        "
      >
        <router-link to="/admin" class="nav-link text-light"
          >管理員介面</router-link
        >
      </li>
    </ul>
    <ul class="nav d-flex align-items-center">
      <li class="nav-item me-3">
        <button
          type="button"
          class="btn btn-outline-light position-relative"
          @click="toggleCart"
        >
          <div class="d-flex align-items-center">
            <div class="mt-m4px pe-1">
              <BIconCart3 />
            </div>
            購物車
          </div>
          <span
            v-if="cartItemCount > 0"
            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
          >
            {{ cartItemCount }}
          </span>
        </button>
      </li>
      <li class="nav-item" v-if="isAuthenticated">
        <a @click="logout" class="nav-link text-light">登出</a>
      </li>
      <li class="nav-item" v-if="!isAuthenticated">
        <router-link to="/login" class="nav-link text-light">登入</router-link>
      </li>
      <li class="nav-item" v-if="!isAuthenticated">
        <router-link to="/register" class="nav-link text-light"
          >註冊</router-link
        >
      </li>
    </ul>
  </nav>
  <CartPopup
    :isCartVisible="isCartVisible"
    @update:cartVisible="(val: boolean) => isCartVisible = val"
  />
</template>

<script setup lang="ts">
import { computed, ref } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";
import { BIconCart3 } from "bootstrap-icons-vue";
import CartPopup from "../../components/CartPopUp.vue";

const store = useStore();
const router = useRouter();

const isAuthenticated = computed(() => store.getters.isAuthenticated);
const userRole = computed(() => store.getters.userRole);
const isCartVisible = ref(false);
const cartItemCount = computed(() => store.getters.cartItemCount);

function toggleCart() {
  isCartVisible.value = !isCartVisible.value;
}

function logout() {
  store.dispatch("logout");
  router.push("/");
}

</script>

<style lang="scss" scoped>
.h-60px {
  height: 70px;
}
.mt-m4px{
  margin-top: -4px;
}
.mt-m10px{
  margin-top: -10px;
}
</style>
