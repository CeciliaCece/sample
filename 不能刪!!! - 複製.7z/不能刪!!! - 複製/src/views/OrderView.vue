<script setup lang="ts">
import CustomerCollapseOrder from "@/components/CustomerCollapseOrder.vue";
import { ref, onMounted } from "vue";
import { useStore } from "vuex";
import axiosInstance from "@/axios";

interface BuyList {
  productId: number;
  productName: string;
  price: number;
  amount: number;
}

interface Order {
  orderId: number;
  username: string;
  orderDate: string;
  status: number;
  invoice: string;
  buylist: BuyList[];
}

const statuses = [
  { value: 1, label: "新訂單" },
  { value: 2, label: "處理中" },
  { value: 3, label: "已出貨" },
  { value: 4, label: "已完成" },
  { value: 5, label: "已取消" },
];

function getStatusLabel(value: number): string {
  const status = statuses.find((status) => status.value === value);
  return status ? status.label : "未知狀態";
}

const orders = ref<Order[]>([]);

const store = useStore();

async function fetchOrders() {
  try {
    const username = store.getters.username;
    const response = await axiosInstance.post("/order/v1/getOrders", {
      body: {
        username: username,
      },
    });
    if (response.data.header.resultCode === "0000") {
      orders.value = response.data.body.orderDetails;
    } else {
      console.error(
        "Failed to fetch orders:",
        response.data.header.resultDescription
      );
    }
  } catch (error) {
    console.error("Error fetching orders:", error);
  }
}

onMounted(fetchOrders);
</script>

<template>
  <div class="container d-flex flex-column align-items-center bg-orange h-100">
    <div class="w-75 m-2 text-darker text-center h-100">
      <ul class="m-0 p-0 d-flex justify-content-between">
        <li class="ms-4">訂單編號</li>
        <li>訂購日期</li>
        <li>訂單狀態</li>
        <li>訂單總額</li>
        <li>訂單發票</li>
        <li class="arrow-width"></li>
      </ul>
    </div>
    <CustomerCollapseOrder
      v-for="(order, index) in orders"
      :key="index"
      :id="order.orderId"
      :date="order.orderDate"
      :status="getStatusLabel(order.status)"
      :invoice="order.invoice"
      :buylist="order.buylist"
    />
  </div>
</template>

<style lang="scss" scoped>
ul {
  text-align: center;
}

li {
  list-style: none;
  padding: 8px 24px;
  width: 144px;
  min-width: 144px;
}

.arrow-width {
  width: 80px;
  min-width: 80px;
}
.bg-orange{
  background-color: #D0AC8A;
}
</style>
