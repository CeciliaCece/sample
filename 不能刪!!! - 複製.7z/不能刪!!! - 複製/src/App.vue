<template>
  <div class="vh-100 d-flex flex-column">
    <nav>
      <NavBar />
    </nav>
    <div class="mt-60px"><router-view /></div>
  </div>
</template>

<script setup lang="ts">
import NavBar from "./views/layouts/NavBar.vue";
</script>

<style lang="scss">
@import "./assets/custom.scss";
.mt-60px {
  margin-top: 70px;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;

  input[type="number"]::-webkit-outer-spin-button,
  input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  input[type="number"] {
    -moz-appearance: textfield;
  }
}
</style>
