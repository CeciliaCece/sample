<template>
  <div>
    <ul class="bg-white m-2 rounded text-primary position-relative">
      <ul
        class="m-0 px-0 py-2 d-flex justify-content-between align-items-center"
        :class="{ 'pb-4': error }"
      >
        <li class="text-end">{{ id }}</li>
        <li>{{ date }}</li>
        <li class="px-2 py-0">
          <select v-model="selectedStatus" class="form-select">
            <option
              v-for="option in statusOptions"
              :key="option.value"
              :value="option.value"
              :disabled="option.disabled"
            >
              {{ option.label }}
            </option>
          </select>
        </li>
        <li class="d-flex justify-content-between">
          <p>NT$</p>
          <p>{{ total }}</p>
        </li>
        <li class="px-2 py-0 position-relative">
          <input
            v-model="currentInvoice"
            class="form-control text-uppercase"
            maxlength="10"
          />
          <div v-if="error" class="text-danger position-absolute fs-7">
            *格式不符
          </div>
        </li>
        <li class="py-0 px-0">
          <a v-if="!collapse" @click="toggleCollapse" class="px-4 py-1 fs-3">
            <BIconArrowDownShort />
          </a>
          <a v-else @click="toggleCollapse" class="px-4 py-1 fs-3">
            <BIconArrowUpShort />
          </a>
        </li>
      </ul>
      <div v-if="collapse">
        <div class="bg-light rounded-bottom fs-6 text-info py-2">
          <ul class="mx-4 my-0 p-0 d-flex justify-content-end text-end">
            <li class="border-bottom">商品名</li>
            <li class="border-bottom">數量</li>
            <li class="border-bottom">價格</li>
            <li class="border-bottom">小計</li>
          </ul>
          <ul
            v-for="item in buylist"
            :key="item.productName"
            class="mx-4 my-0 p-0 d-flex justify-content-end text-end"
          >
            <li class="flex-fill border-bottom">{{ item.productName }}</li>
            <li class="border-bottom">{{ item.amount }}</li>
            <li class="d-flex justify-content-between border-bottom">
              <p>NT$</p>
              <p>{{ item.price }}</p>
            </li>
            <li class="d-flex justify-content-between border-bottom">
              <p>NT$</p>
              <p>{{ item.amount * item.price }}</p>
            </li>
          </ul>
        </div>
      </div>
      <div class="fs-1 position-absolute top-0 start-100 d-flex">
        <a @click="saveOrder">
          <BIconCheck class="text-success" />
        </a>
        <a @click="returnOrder">
          <BIconX class="text-danger" />
        </a>
      </div>
    </ul>
  </div>
</template>

<script setup lang="ts">
import { ref, defineProps, computed } from "vue";
import {
  BIconArrowDownShort,
  BIconArrowUpShort,
  BIconCheck,
  BIconX,
} from "bootstrap-icons-vue";
import axiosInstance from "@/axios";

interface Buylist {
  productName: string;
  amount: number;
  price: number;
}

const props = defineProps<{
  id: number;
  date: string;
  status: number;
  invoice: string;
  buylist: Buylist[];
}>();

const collapse = ref(false);
const error = ref(false);
const selectedStatus = ref(props.status.toString());
const currentInvoice = ref(props.invoice);

const statuses = [
  { value: "1", label: "新訂單" },
  { value: "2", label: "處理中" },
  { value: "3", label: "已出貨" },
  { value: "4", label: "已完成" },
  { value: "5", label: "已取消" },
];

const total = computed(() => {
  return props.buylist.reduce((acc, item) => acc + item.amount * item.price, 0);
});

const statusOptions = computed(() => {
  const initialIndex = statuses.findIndex(
    (status) => status.value === props.status.toString()
  );
  return statuses.map((status, index) => ({
    ...status,
    disabled: index < initialIndex,
  }));
});

function toggleCollapse() {
  collapse.value = !collapse.value;
}

async function saveOrder() {
  const invoicePattern = /^[A-Za-z]{2}\d{8}$/;
  if (!invoicePattern.test(currentInvoice.value)) {
    error.value = true;
  } else {
    error.value = false;
    try {
      const response = await axiosInstance.post("/order/v1/updateOrder", {
        body: {
          orderId: props.id,
          status: selectedStatus.value,
          invoice: currentInvoice.value,
        },
      });
      if (response.data.header.resultCode === "0000") {
        alert("訂單已更新");
        console.log("訂單已更新");
      } else {
        console.error("更新訂單失敗:", response.data.header.resultDescription);
      }
    } catch (error) {
      console.error("更新訂單錯誤:", error);
    }
  }
}

function returnOrder() {
  selectedStatus.value = props.status.toString();
  currentInvoice.value = props.invoice;
  error.value = false;
}
</script>

<style lang="scss" scoped>
ul {
  text-align: center;
}

li {
  list-style: none;
  padding: 8px 24px;
  width: 144px;
  min-width: 144px;
  margin: 0px 10px;
}

p {
  margin: 0;
}
</style>
