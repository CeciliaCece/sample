<script setup lang="ts">
import { ref, computed, onMounted, defineProps,defineEmits } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";
import axiosInstance from "@/axios";

const store = useStore();
const router = useRouter();

const props = defineProps<{
  isCartVisible: boolean;
  toggleCart: () => void;
}>();

const emit = defineEmits(["update:cartVisible"]);

interface BuyList {
  productId: number;
  productName: string;
  amount: number;
  price: number;
  originalAmount?: number;
  isAmountChanged?: boolean;
}

const buylist = ref<BuyList[]>([]);

async function postGet() {
  try {
    const username = store.getters.username;
    const response = await axiosInstance.post("/cart/v1/getCart", {
      body: {
        username: username,
      },
    });
    if (response.data.header.resultCode === "0000") {
      const fetchedBuylist = response.data.body.buylist.map(
        (item: BuyList) => ({
          ...item,
          originalAmount: item.amount,
          isAmountChanged: false,
        })
      );
      store.dispatch("setCart", fetchedBuylist);
      buylist.value = fetchedBuylist;
    } else {
      console.error("Failed to fetch cart:", response);
    }
  } catch (error) {
    console.error("Error fetching cart data:", error);
  }
}

onMounted(() => {
  if (store.getters.isAuthenticated) {
    postGet();
  } else {
    buylist.value = store.getters.buylist;
  }
});

const total = computed(() => {
  return buylist.value.reduce((acc, item) => acc + item.amount * item.price, 0);
});

const incrementAmount = (item: BuyList) => {
  item.amount++;
  item.isAmountChanged = item.amount !== item.originalAmount;
};

const decrementAmount = (item: BuyList) => {
  if (item.amount > 1) {
    item.amount--;
    item.isAmountChanged = item.amount !== item.originalAmount;
  }
};

const postRemove = async (productId: number) => {
  try {
    if (store.getters.isAuthenticated) {
      const username = store.getters.username;
      const response = await axiosInstance.post("/cart/v1/deleteCart", {
        body: {
          productId: productId,
          username: username,
        },
      });
      if (response.data.header.resultCode === "0000") {
        buylist.value = buylist.value.filter(
          (item) => item.productId !== productId
        );
        store.dispatch("setCart", buylist.value);
        alert("商品已移除");
      } else {
        console.error("Failed to remove item:", response);
        alert("移除商品失敗");
      }
    } else {
      buylist.value = buylist.value.filter(
        (item) => item.productId !== productId
      );
      store.dispatch("setCart", buylist.value);
    }
  } catch (error) {
    console.error("Error removing item:", error);
    alert("移除商品失敗");
  }
};
const postUpdate = async (item: BuyList) => {
  try {
    if (store.getters.isAuthenticated) {
      const username = store.getters.username;
      const response = await axiosInstance.post("/cart/v1/updateCart", {
        body: {
          productId: item.productId,
          username: username,
          amount: item.amount,
        },
      });
      if (response.data.header.resultCode === "0000") {
        item.originalAmount = item.amount;
        item.isAmountChanged = false;
        store.dispatch("setCart", buylist.value);
        alert("商品數量已更新");
      } else {
        console.error("Failed to update item:", response);
        alert("更新商品數量失敗");
      }
    } else {
      item.originalAmount = item.amount;
      item.isAmountChanged = false;
      store.dispatch("setCart", buylist.value);
    }
  } catch (error) {
    console.error("Error updating item:", error);
    alert("更新商品數量失敗");
  }
};

const checkout = async () => {
  if (!store.getters.token) {
    emit("update:cartVisible", false);
    router.push("/login");
    alert('結帳需先登入會員')
    return;
  }
  try {
    const username = store.getters.username;
    const orderDate = new Date().toISOString().split("T")[0];
    const invoice = `IN${Math.floor(Math.random() * 100000000)
      .toString()
      .padStart(8, "0")}`;

    const response = await axiosInstance.post("/order/v1/addOrder", {
      body: {
        username: username,
        orderDate: orderDate,
        invoice: invoice,
      },
    });

    if (response.data.header.resultCode === "0000") {
      alert("訂單已成功提交");
      buylist.value = [];
      store.dispatch("setCart", []);
      emit("update:cartVisible", false);
      router.push("/order");
    } else {
      console.error("Failed to place order:", response);
      alert("提交訂單失敗");
    }
  } catch (error) {
    console.error("Error placing order:", error);
    alert("提交訂單失敗");
  }
};
</script>

<template>
  <div
    v-show="props.isCartVisible"
    class="position-relative position-fixed vw-100 vh-100 z-3"
  >
    <div class="position-absolute bg-black opacity-25 vw-100 vh-100"></div>
    <div class="card position-absolute top-50 start-50 translate-middle">
      <div class="card-header">
        <h5 class="card-title mt-2">購物車</h5>
      </div>
      <div class="card-body">
        <div class="fs-6 text-info py-2">
          <ul
            class="mx-4 mb-2 d-flex justify-content-end text-end border-bottom"
          >
            <li class="pe-2">商品名</li>
            <li class="pe-2">數量</li>
            <li class="pe-2">價格</li>
            <li class="pe-2">小計</li>
            <li></li>
          </ul>
          <ul
            v-for="item in buylist"
            :key="item.productId"
            class="mx-4 my-0 p-0 d-flex justify-content-end text-end"
          >
            <li class="flex-fill border-bottom">{{ item.productName }}</li>
            <li>
              <div class="input-group-sm d-flex">
                <button
                  @click="incrementAmount(item)"
                  class="input-group-text reset-rounded-start"
                >
                  ＋
                </button>
                <input
                  type="number"
                  class="form-control text-center rounded-0 border-y"
                  v-model="item.amount"
                />
                <button
                  @click="decrementAmount(item)"
                  class="input-group-text reset-rounded-end"
                >
                  －
                </button>
              </div>
            </li>
            <li class="d-flex justify-content-between border-bottom">
              <p>NT$</p>
              <p>{{ item.price }}</p>
            </li>
            <li class="d-flex justify-content-between border-bottom">
              <p>NT$</p>
              <p>{{ item.amount * item.price }}</p>
            </li>
            <li>
              <button
                @click="postUpdate(item)"
                class="btn btn-outline-primary btn-sm me-3"
                :disabled="!item.isAmountChanged"
              >
                儲存
              </button>
              <button
                @click="postRemove(item.productId)"
                class="btn btn-outline-danger btn-sm"
              >
                刪除
              </button>
            </li>
          </ul>
          <div class="d-flex justify-content-end align-items-center mt-4 me-3">
            <p class="me-3">總計</p>
            <div
              class="d-flex justify-content-between w-mw-120px border-bottom"
            >
              <p>NT$</p>
              <p>{{ total }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="card-footer d-flex justify-content-end p-3">
        <a @click="emit('update:cartVisible', false)" class="btn btn-outline-primary btn-sm me-3"
          >關閉視窗</a
        >
        <a @click="checkout" class="btn btn-primary btn-sm">立即結帳</a>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
li {
  list-style: none;
  margin: 8px 24px;
  width: 120px;
  min-width: 120px;
}

p {
  margin: 0;
}

.reset-rounded-end {
  border-radius: 0 4px 4px 0 !important;
}
.reset-rounded-start {
  border-radius: 4px 0 0 4px !important;
}
.border-y {
  border-width: 0.75px 0 0.75px 0 !important;
}

.w-mw-120px {
  width: 120px;
  min-width: 120px;
}

.li-border {
  border-bottom: 1px;
}
</style>
