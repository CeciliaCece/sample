<template>
    <div class="bg-white w-75 m-2 rounded text-primary">
        <ul class="m-0 p-0 py-2 d-flex justify-content-between">
            <li class="ms-4 text-end">{{ id }}</li>
            <li>{{ date }}</li>
            <li>{{ status }}</li>
            <li class="d-flex justify-content-between">
                <p>NT$</p>
                <p>{{ total }}</p>
            </li>
            <li>{{ invoice }}</li>
            <a v-if="collapse" @click="toggleCollapse" class="px-4  fs-4 arrow-width">
                <BIconArrowUpShort />
            </a>
            <a v-else @click="toggleCollapse" class="px-4  fs-4 arrow-width">
                <BIconArrowDownShort />
            </a>
        </ul>
        <div v-if="collapse" class="bg-light rounded-bottom fs-6 text-info py-2">
            <ul class="mx-4 my-0 p-0 d-flex justify-content-end text-end">
                <li>商品名</li>
                <li>數量</li>
                <li>價格</li>
                <li>小計</li>
            </ul>
            <ul v-for="item in buylist" :key="item.productName"
                class="mx-4 my-0 p-0 d-flex justify-content-end text-end">
                <li class="flex-fill">{{ item.productName }}</li>
                <li>{{ item.amount }}</li>
                <li class="d-flex justify-content-between">
                    <p>NT$</p>
                    <p>{{ item.price }}</p>
                </li>
                <li class="d-flex justify-content-between">
                    <p>NT$</p>
                    <p>{{ item.amount * item.price }}</p>
                </li>
            </ul>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, defineProps, computed } from "vue";
import { BIconArrowDownShort, BIconArrowUpShort } from "bootstrap-icons-vue";

const collapse = ref(false);

function toggleCollapse() {
    collapse.value = !collapse.value;
}

interface Buylist {
    productName: string;
    amount: number;
    price: number;
}

const props = defineProps<{
    id: number;
    date: string;
    status: string;
    invoice: string;
    buylist: Buylist[];
}>();

const total = computed(() => {
    return props.buylist.reduce(
        (acc, item) => acc + item.amount * item.price,
        0
    );
});
</script>

<style lang="scss" scoped>
ul {
    text-align: center;
}

li {
    list-style: none;
    padding: 8px 24px;
    width: 144px;
    min-width: 144px;
}

p {
    margin: 0;
}

.arrow-width {
    width: 80px;
    min-width: 80px;
}
</style>