<script setup lang="ts">
import { defineProps, computed } from "vue";
import { useRouter } from "vue-router";
import { useStore } from "vuex";
import axiosInstance from "@/axios";

const props = defineProps<{
  productId: number;
  productName: string;
  description: string;
  price: number;
  stock: number;
}>();

const router = useRouter();
const store = useStore();

const goToProductDetails = () => {
  router.push(`/product/${props.productId}`);
};

const isOutOfStock = computed(() => props.stock === 0);
const cartButtonText = computed(() =>
  isOutOfStock.value ? "完售" : "加入購物車"
);

const addToCart = async () => {
  try {
    const username = store.getters.username;
    if (store.getters.isAuthenticated) {
      await axiosInstance.post("/cart/v1/addCart", {
        body: {
          productId: props.productId,
          username: username,
          amount: 1,
        },
      });
      alert("商品已加入購物車");
    } else {
      const newCartItem = {
        productId: props.productId,
        productName: props.productName,
        price: props.price,
        amount: 1,
      };
      console.log(newCartItem);
      store.dispatch("addToCart", newCartItem);
      alert("商品已加入購物車");
    }
  } catch (error) {
    console.error("加入購物車失敗", error);
    alert("加入購物車失敗");
  }
};
</script>

<template>
  <div class="card my-2 mx-3 width-288px" style="width: 18rem">
    <img src="../assets/card_image.jpg" alt="產品圖片" class="card-img-top" />
    <div class="card-body">
      <h4 class="card-title text-primary">{{ props.productName }}</h4>
      <p class="card-text text-secondary">{{ props.description }}</p>
      <p class="card-text fs-4 fw-bold text-end">NT$ {{ props.price }}</p>
    </div>
    <div class="card-footer bg-primary">
      <div class="d-flex justify-content-between">
        <button
          type="button"
          class="btn btn-outline-light my-1"
          @click="goToProductDetails"
        >
          查看更多
        </button>
        <button
          type="button"
          class="btn btn-outline-secondary my-1"
          :disabled="isOutOfStock"
          @click="addToCart"
        >
          {{ cartButtonText }}
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.width-288px {
  width: 288px;
}
</style>
