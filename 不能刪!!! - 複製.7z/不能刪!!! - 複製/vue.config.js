const { defineConfig } = require("@vue/cli-service");
module.exports = defineConfig({
  transpileDependencies: true,

  devServer: {
    open: true,
    proxy: {
      "/localhost": {
        // 监听拦截以/localhost开头的请求接口，并替换成target
        target: "http://192.168.0.164:15593/traveltogether", //  需要代理的目标url,本地就ipconfig查看域名地址
        // target: "http://xx.xx.xxx.xxx:xxxx", //  后端服务器部署的域名地址，即后端接口
        changeOrigin: true, // 开启代理，允许跨域
        secure: false, // 如果使用https，会有安全校验，添加设置secure为false
        pathRewrite: {
          // 重写匹配的字段，如果不需要在请求路径上，重写为""
          "^/localhost": "",
        },
      },
    },
  },
});
